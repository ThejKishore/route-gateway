FIS, or **Fidelity National Information Services**, is a global financial services technology company. It provides a broad range of solutions and services to financial institutions, including banks, credit unions, and investment firms. Here's a more detailed overview of FIS:

### **1. **Company Overview

- **Founded:** 1968
- **Headquarters:** Jacksonville, Florida, USA
- **Industry:** Financial services technology
- **Publicly Traded:** Yes, listed on the New York Stock Exchange (NYSE) under the ticker symbol FIS.

### **2. **Key Services and Solutions

FIS offers a wide array of services and technology solutions, which can be broadly categorized into several areas:

#### **a. **Banking and Payments:**
- **Core Banking Solutions:** Comprehensive software systems that manage daily banking operations, including account management, transaction processing, and compliance.
- **Payment Processing:** Solutions for processing various payment types, including credit card transactions, debit card transactions, and electronic payments.
- **Digital Banking:** Platforms and services that enable banks and credit unions to offer online and mobile banking experiences to their customers.

#### **b. **Capital Markets:**
- **Trading Solutions:** Technology for trading, including electronic trading platforms and tools for managing trading operations and risk.
- **Investment Management:** Solutions for managing investments, including portfolio management and trading systems.

#### **c. **Risk, Compliance, and Fraud:**
- **Fraud Detection:** Systems and tools for detecting and preventing fraudulent activities.
- **Regulatory Compliance:** Solutions to help financial institutions comply with various regulations and standards.

#### **d. **Insurance:**
- **Policy Administration:** Systems for managing insurance policies, claims, and underwriting processes.
- **Claims Management:** Solutions for processing and managing insurance claims.

### **3. **Acquisitions and Expansion**

FIS has expanded its capabilities and market presence through various acquisitions. Some notable acquisitions include:

- **Worldpay:** A global payment processing company acquired by FIS in 2019. This acquisition significantly enhanced FIS's payment processing capabilities and global reach.
- **SunGard:** Acquired in 2015, SunGard brought a range of financial services technology solutions to FIS, including risk management and trading systems.

### **4. **Global Presence**

FIS operates globally, serving financial institutions, merchants, and other clients in numerous countries. Its global footprint allows it to provide localized solutions and support to a diverse client base.

### **5. **Innovation and Technology**

FIS invests heavily in innovation and technology to stay at the forefront of financial services technology. This includes advancements in areas like blockchain, artificial intelligence, and machine learning to enhance financial operations and customer experiences.

### **Summary**

FIS is a leading provider of technology solutions and services for the financial industry, offering a comprehensive range of products that support banking, payments, capital markets, and insurance. Its global presence, coupled with a focus on innovation and acquisitions, positions it as a major player in the financial services technology sector.

## Banking solution

FIS (Fidelity National Information Services) plays a crucial role in facilitating money movement between checking accounts through its suite of banking and payments solutions. Here’s a detailed overview of how FIS supports and enhances the process of moving money between checking accounts:

### **1. **Core Banking Solutions

#### **a. Core Banking Systems:**
- **Account Management:** FIS provides core banking systems that manage checking accounts, including balance maintenance, transaction processing, and account reconciliation.
- **Transaction Processing:** These systems handle the processing of transactions such as deposits, withdrawals, and transfers between accounts.

### **2. **Payment Processing Solutions

#### **a. Electronic Funds Transfer (EFT):**
- **ACH Transfers:** FIS supports Automated Clearing House (ACH) transfers, allowing for electronic movement of funds between checking accounts within the same bank or across different banks. This includes both ACH credits (for deposits) and ACH debits (for withdrawals).
- **Direct Deposit:** FIS provides solutions for direct deposit services, ensuring that payroll or other regular payments are deposited directly into checking accounts.

#### **b. Wire Transfers:**
- **Domestic Wire Transfers:** FIS offers solutions for domestic wire transfers, which are used for high-value and urgent transfers between checking accounts. This service includes real-time processing and settlement of funds.
- **International Wire Transfers:** For international transactions, FIS facilitates cross-border wire transfers, managing currency conversion and compliance with international banking regulations.

### **3. **Digital Banking and Mobile Solutions

#### **a. Online Banking:**
- **Account Access:** FIS provides online banking platforms that allow customers to view account balances, transfer funds between checking accounts, and manage transactions online.
- **Funds Transfer:** Customers can initiate transfers between their own checking accounts or to other accounts within the same bank or at different banks using FIS’s online banking services.

#### **b. Mobile Banking:**
- **Mobile Apps:** FIS offers mobile banking applications that enable users to perform transactions, including transferring money between checking accounts, from their smartphones or tablets.
- **Mobile Check Deposit:** This feature allows users to deposit checks into their checking accounts using their mobile device’s camera.

### **4. **Real-Time Payments (RTP)**

#### **a. Instant Transfers:**
- **FIS's RTP Solutions:** FIS supports Real-Time Payments (RTP) systems that enable instant money movement between checking accounts, providing immediate fund availability and settlement.

### **5. **Fraud Prevention and Security**

#### **a. Fraud Detection:**
- **Monitoring Tools:** FIS provides fraud detection and prevention tools that monitor transactions for suspicious activity, protecting against unauthorized transfers and ensuring secure money movement between checking accounts.

#### **b. Compliance and Risk Management:**
- **Regulatory Compliance:** FIS’s solutions help financial institutions comply with regulations and manage risks associated with money transfers, including anti-money laundering (AML) and know-your-customer (KYC) requirements.

### **6. **Customer Experience and Support**

#### **a. Customer Service Tools:**
- **Support Solutions:** FIS offers customer service tools and support solutions to assist with any issues or inquiries related to money movement between checking accounts.

### **Summary**

FIS enhances the movement of money between checking accounts through a range of services and technologies:

- **Core Banking Systems** manage and process transactions.
- **Payment Processing Solutions** include ACH and wire transfers for domestic and international transactions.
- **Digital and Mobile Banking** solutions provide convenient access and management of accounts.
- **Real-Time Payments** enable instant transfers.
- **Fraud Prevention and Security** tools ensure safe and compliant transactions.
- **Customer Support** assists with transaction-related inquiries.

By integrating these solutions, FIS supports efficient, secure, and reliable money movement between checking accounts for both financial institutions and their customers.

Certainly! Here’s how you can represent various money movement flows between checking accounts using Mermaid.js. I’ll include diagrams for different types of transactions:

1. **Internal Transfers within the Same Bank**
2. **ACH Transfers**
3. **Wire Transfers**
4. **Real-Time Payments (RTP)**

### **1. Internal Transfers within the Same Bank**

```mermaid
flowchart TD
    A[Customer Initiates Transfer] --> B[Bank Processes Transfer]
    B --> C[Update Both Accounts]
    C --> D[Confirmation Sent to Customer]

    classDef startend fill:#bbf,stroke:#333,stroke-width:2px;
    classDef process fill:#f9f,stroke:#333,stroke-width:2px;

    class A,D startend;
    class B,C process;
```

### **Explanation:**
- **Customer Initiates Transfer:** The customer requests to move money between their own checking accounts.
- **Bank Processes Transfer:** The bank processes the request internally.
- **Update Both Accounts:** The bank updates the balances of the sending and receiving accounts.
- **Confirmation Sent to Customer:** The customer receives confirmation that the transfer is complete.

### **2. ACH Transfers**

```mermaid
flowchart TD
    A[Customer Initiates ACH Transfer] --> B[Bank A Processes ACH Request]
    B --> C[Bank A Sends ACH Request to ACH Network]
    C --> D[ACH Network Routes Request to Bank B]
    D --> E[Bank B Receives ACH Request]
    E --> F[Bank B Credits Receiver’s Account]
    F --> G[Bank B Sends Confirmation to ACH Network]
    G --> H[ACH Network Sends Confirmation to Bank A]
    H --> I[Bank A Notifies Customer of Completion]

    classDef startend fill:#bbf,stroke:#333,stroke-width:2px;
    classDef process fill:#f9f,stroke:#333,stroke-width:2px;

    class A,I startend;
    class B,C,D,E,F,G,H process;
```

### **Explanation:**
- **Customer Initiates ACH Transfer:** The customer requests an ACH transfer.
- **Bank A Processes ACH Request:** Bank A processes the ACH transfer request.
- **Bank A Sends ACH Request to ACH Network:** The request is sent to the ACH network.
- **ACH Network Routes Request to Bank B:** The ACH network routes the request to the recipient’s bank.
- **Bank B Receives ACH Request:** Bank B receives the ACH transfer request.
- **Bank B Credits Receiver’s Account:** Bank B credits the receiver’s account.
- **Bank B Sends Confirmation to ACH Network:** Bank B confirms the transfer to the ACH network.
- **ACH Network Sends Confirmation to Bank A:** The ACH network sends confirmation to Bank A.
- **Bank A Notifies Customer of Completion:** Bank A notifies the customer that the transfer is complete.

### **3. Wire Transfers**

```mermaid
flowchart TD
    A[Customer Initiates Wire Transfer] --> B[Bank A Processes Wire Request]
    B --> C[Bank A Sends Wire Transfer to Fedwire/CHIPS]
    C --> D[Fedwire/CHIPS Processes Transfer]
    D --> E[Bank B Receives Wire Transfer]
    E --> F[Bank B Credits Receiver’s Account]
    F --> G[Bank B Sends Confirmation to Fedwire/CHIPS]
    G --> H[Fedwire/CHIPS Sends Confirmation to Bank A]
    H --> I[Bank A Notifies Customer of Completion]

    classDef startend fill:#bbf,stroke:#333,stroke-width:2px;
    classDef process fill:#f9f,stroke:#333,stroke-width:2px;

    class A,I startend;
    class B,C,D,E,F,G,H process;
```

### **Explanation:**
- **Customer Initiates Wire Transfer:** The customer requests a wire transfer.
- **Bank A Processes Wire Request:** Bank A processes the wire transfer request.
- **Bank A Sends Wire Transfer to Fedwire/CHIPS:** The request is sent to the Fedwire or CHIPS system.
- **Fedwire/CHIPS Processes Transfer:** The transfer is processed through the wire transfer system.
- **Bank B Receives Wire Transfer:** Bank B receives the wire transfer.
- **Bank B Credits Receiver’s Account:** Bank B credits the receiver’s account.
- **Bank B Sends Confirmation to Fedwire/CHIPS:** Confirmation is sent to the wire transfer system.
- **Fedwire/CHIPS Sends Confirmation to Bank A:** Confirmation is sent back to Bank A.
- **Bank A Notifies Customer of Completion:** Bank A notifies the customer that the transfer is complete.

### **4. Real-Time Payments (RTP)**

```mermaid
flowchart TD
    A[Customer Initiates RTP Transfer] --> B[Bank A Processes RTP Request]
    B --> C[Bank A Sends RTP Request to RTP Network]
    C --> D[RTP Network Processes Transfer]
    D --> E[Bank B Receives RTP Request]
    E --> F[Bank B Credits Receiver’s Account]
    F --> G[Bank B Sends Confirmation to RTP Network]
    G --> H[RTP Network Sends Confirmation to Bank A]
    H --> I[Bank A Notifies Customer of Completion]

    classDef startend fill:#bbf,stroke:#333,stroke-width:2px;
    classDef process fill:#f9f,stroke:#333,stroke-width:2px;

    class A,I startend;
    class B,C,D,E,F,G,H process;
```

### **Explanation:**
- **Customer Initiates RTP Transfer:** The customer requests an RTP transfer.
- **Bank A Processes RTP Request:** Bank A processes the RTP transfer request.
- **Bank A Sends RTP Request to RTP Network:** The request is sent to the RTP network.
- **RTP Network Processes Transfer:** The RTP network processes the transfer in real-time.
- **Bank B Receives RTP Request:** Bank B receives the RTP transfer request.
- **Bank B Credits Receiver’s Account:** Bank B credits the receiver’s account immediately.
- **Bank B Sends Confirmation to RTP Network:** Confirmation is sent to the RTP network.
- **RTP Network Sends Confirmation to Bank A:** Confirmation is sent back to Bank A.
- **Bank A Notifies Customer of Completion:** Bank A notifies the customer that the transfer is complete.

These diagrams provide a clear visual representation of the different methods used for transferring money between checking accounts and highlight the role of each participant in the process.