**Wire transfers** are a method of electronic funds transfer (EFT) that allows individuals and organizations to send money from one bank account to another securely and quickly. Wire transfers are commonly used for high-value transactions, international payments, and time-sensitive transfers.

### **Key Characteristics of Wire Transfers**

1. **Electronic Transfer:**
    - Wire transfers are conducted electronically through financial institutions and payment networks.

2. **Speed:**
    - Wire transfers are typically processed quickly, often within the same day or within one business day.

3. **Security:**
    - Wire transfers are considered secure due to the use of financial institutions and secure communication channels.

4. **Finality:**
    - Once completed, wire transfers are generally considered final and irreversible. This means that funds cannot be easily reversed or canceled.

5. **Cost:**
    - Wire transfers often incur fees, which can vary based on the sending and receiving banks, the amount transferred, and whether the transfer is domestic or international.

### **How Wire Transfers Work**

#### **1. Initiation:**

- **Sender Instructions:**
    - The sender provides their bank with instructions to transfer funds to another account. This typically includes details such as the recipient's name, bank account number, routing number (for domestic transfers), and SWIFT/BIC code (for international transfers).

- **Bank Verification:**
    - The sender’s bank verifies the instructions and ensures that sufficient funds are available in the sender’s account.

#### **2. Transmission:**

- **Domestic Transfers:**
    - For domestic wire transfers, the sender's bank sends the transfer request through the relevant domestic wire transfer system, such as the Federal Reserve’s Fedwire system or the Clearing House Interbank Payments System (CHIPS) in the United States.

- **International Transfers:**
    - For international wire transfers, the sender's bank uses the SWIFT network (Society for Worldwide Interbank Financial Telecommunication) to transmit the transfer request. The SWIFT network facilitates communication between banks across the globe.

#### **3. Processing:**

- **Receiving Bank:**
    - The receiving bank receives the wire transfer request through the appropriate system (domestic or international). It processes the transfer, ensuring the recipient’s account details are correct and that the funds are deposited into the recipient's account.

- **Intermediary Banks:**
    - For international transfers, intermediary banks may be involved. These banks help facilitate the transfer between the sender’s bank and the recipient’s bank, especially if the banks do not have a direct relationship.

#### **4. Completion:**

- **Funds Transfer:**
    - Once the receiving bank processes the wire transfer, the funds are credited to the recipient’s account. The recipient can then access the funds as per their bank’s policies.

- **Notification:**
    - Both the sender and recipient are usually notified of the successful completion of the wire transfer. Confirmation may be provided via email, text message, or through the banks' online systems.

### **Example of a Wire Transfer Process**

1. **Sender:** Alice wants to send $5,000 to Bob.
2. **Initiation:**
    - Alice provides her bank (Bank A) with Bob’s account details, including Bob’s bank (Bank B) routing number.
    - Bank A verifies Alice’s account and the transfer details.

3. **Transmission:**
    - Bank A sends a wire transfer request to Bank B using the SWIFT network.

4. **Processing:**
    - Bank B receives the transfer request, verifies the details, and credits Bob’s account with $5,000.

5. **Completion:**
    - Bob receives the funds in his account, and both Alice and Bob are notified of the successful transfer.

### **Considerations for Wire Transfers**

1. **Fees:**
    - Both sending and receiving banks may charge fees for wire transfers. Fees can vary based on the amount, destination, and urgency of the transfer.

2. **Accuracy:**
    - Ensuring accurate account details is crucial, as wire transfers are difficult to reverse once completed.

3. **Security:**
    - Wire transfers are secure, but it’s important to verify the recipient’s details and be cautious of potential fraud or phishing schemes.

4. **Timing:**
    - While wire transfers are generally fast, the exact timing may vary based on the banks involved and the time of day the transfer is initiated.

### **Summary**

Wire transfers are a secure and efficient way to move funds electronically between bank accounts. They involve several steps, including initiation, transmission, processing, and completion. Wire transfers are commonly used for large or urgent transactions, and they offer a reliable means of transferring money both domestically and internationally.

## Federal Reserve’s Fedwire system or the Clearing House Interbank Payments System (CHIPS)

**Domestic wire transfers** in the United States can be processed through two major systems: the **Federal Reserve’s Fedwire system** and the **Clearing House Interbank Payments System (CHIPS)**. Both systems are used to facilitate the transfer of funds between financial institutions, but they operate differently and serve different purposes.

### **1. Fedwire System**

#### **Overview:**
- **Fedwire** is a real-time gross settlement (RTGS) system operated by the Federal Reserve. It enables U.S. banks to transfer funds and settle payments on a real-time basis.

#### **Key Features:**

1. **Real-Time Processing:**
    - Transactions are settled in real-time, meaning that funds are transferred and settled immediately as the transaction is processed.

2. **Gross Settlement:**
    - Fedwire processes each transaction individually and settles it in full. This means there is no netting of transactions; each transfer is completed on a one-to-one basis.

3. **High-Value Transactions:**
    - Fedwire is typically used for high-value transactions and large sums of money, making it suitable for financial institutions and corporate transactions.

4. **Security and Reliability:**
    - Fedwire transactions are considered secure and reliable, as they are processed by the Federal Reserve, which provides a stable and trusted infrastructure.

5. **Hours of Operation:**
    - Fedwire operates during business hours, with a cut-off time for transactions typically around 6:30 PM ET, though it may vary.

#### **Example of a Fedwire Transaction:**

1. **Initiation:**
    - Bank A instructs Fedwire to transfer $1 million to Bank B.

2. **Processing:**
    - Fedwire verifies and processes the transaction in real-time, transferring the $1 million from Bank A’s reserve account to Bank B’s reserve account.

3. **Settlement:**
    - Bank B receives the funds immediately and credits the recipient’s account accordingly.

### **2. CHIPS (Clearing House Interbank Payments System)**

#### **Overview:**
- **CHIPS** is a private-sector, multi-currency, large-value payment system operated by The Clearing House. It facilitates the settlement of large, high-value transactions between banks.

#### **Key Features:**

1. **Net Settlement:**
    - CHIPS uses a netting system where transactions are netted out during the day. Instead of settling each transaction individually, CHIPS calculates net positions and settles the net amounts at the end of the day.

2. **High-Value Transactions:**
    - Similar to Fedwire, CHIPS is designed for high-value transactions and is used for large-dollar payments and international transactions.

3. **Efficiency:**
    - Net settlement reduces the amount of liquidity required and improves the efficiency of the payment process by settling only the net amounts due.

4. **Operational Hours:**
    - CHIPS operates from 8:30 AM to 5:00 PM ET, with multiple settlement cycles throughout the day.

5. **Security:**
    - CHIPS transactions are secure, with robust risk management and compliance measures in place to ensure the integrity of the payment system.

#### **Example of a CHIPS Transaction:**

1. **Initiation:**
    - Bank A instructs CHIPS to send $500,000 to Bank B.

2. **Processing:**
    - CHIPS processes and nets the transaction with other transactions throughout the day. At the end of the day, the net settlement amount is calculated.

3. **Settlement:**
    - The net amount due from Bank A to Bank B is settled based on the netting process. Bank B receives the net amount, and the transactions are reconciled accordingly.

### **Comparison of Fedwire and CHIPS**

1. **Settlement Type:**
    - **Fedwire:** Real-time gross settlement.
    - **CHIPS:** Net settlement.

2. **Transaction Size:**
    - Both systems are used for high-value transactions, but Fedwire processes each transaction individually while CHIPS settles net positions.

3. **Usage:**
    - **Fedwire:** Often used for high-value domestic transactions requiring immediate settlement.
    - **CHIPS:** Commonly used for large-value domestic and international transactions, focusing on efficiency through netting.

4. **Operational Model:**
    - **Fedwire:** Operated by the Federal Reserve.
    - **CHIPS:** Operated by The Clearing House, a private-sector organization.

### **Summary**

Fedwire and CHIPS are two primary systems for processing domestic wire transfers in the U.S. Fedwire provides real-time gross settlement, processing transactions individually and immediately. CHIPS uses a net settlement approach, calculating net positions and settling amounts at the end of the day. Both systems are integral to the U.S. financial system, facilitating large-value transactions efficiently and securely.

## SWIFT

International wire transfers are typically conducted through the **SWIFT network**, which facilitates secure and standardized communication between banks worldwide. Here’s a detailed look at how SWIFT works, including how transactions are traced and troubleshot.

### **1. Overview of SWIFT**

#### **SWIFT (Society for Worldwide Interbank Financial Telecommunication):**
- **Purpose:** SWIFT is a global messaging network that financial institutions use to securely transmit information and instructions for international wire transfers.
- **Function:** SWIFT does not handle the actual transfer of funds; rather, it provides a standardized messaging system that allows banks to communicate instructions regarding the transfer of funds.

### **2. How SWIFT Works**

#### **Step-by-Step Process:**

1. **Initiation:**
    - **Sender:** The sender provides their bank (Bank A) with details for an international wire transfer, including the recipient’s bank details, amount, currency, and any additional instructions.

2. **SWIFT Message Creation:**
    - **Message Type:** Bank A generates a SWIFT message using a standardized format, such as MT103 (for customer credit transfer) or MT202 (for bank-to-bank transfers).
    - **Message Content:** Includes essential details such as the recipient’s bank (Bank B) SWIFT/BIC code, account number, transfer amount, and currency.

3. **Transmission:**
    - **SWIFT Network:** Bank A sends the SWIFT message through the SWIFT network. This network uses a secure, encrypted channel to transmit messages between banks globally.

4. **Processing by Receiving Bank:**
    - **Bank B:** The recipient bank (Bank B) receives the SWIFT message through the SWIFT network, processes the instructions, and credits the recipient’s account.
    - **Intermediary Banks:** If Bank A and Bank B do not have a direct relationship, intermediary banks may be involved to facilitate the transfer. These intermediaries also use SWIFT to communicate the transfer details.

5. **Settlement:**
    - **Funds Transfer:** The actual transfer of funds is conducted through other settlement systems (e.g., Fedwire, CHIPS) or correspondent banking networks. SWIFT facilitates the communication and instruction but does not handle the funds directly.

6. **Confirmation:**
    - **Notification:** Both the sender and recipient are typically notified of the successful transfer. This confirmation may come from the sending or receiving bank, or through SWIFT messages.

### **3. SWIFT Messaging Types**

- **MT103:** Standard message for customer credit transfers, used to instruct a bank to pay a specified amount to a beneficiary.
- **MT202:** Used for financial institution transfers, such as the transfer of funds between banks.

### **4. Transaction Tracking and Troubleshooting**

#### **Tracking Transactions:**

1. **Reference Numbers:**
    - **Unique Identifier:** Each SWIFT message includes a unique reference number that helps track the transaction throughout the process.
    - **Transaction ID:** This ID allows banks and customers to trace the status of the transfer.

2. **SWIFT gpi (Global Payments Innovation):**
    - **Enhanced Tracking:** SWIFT gpi provides real-time tracking and transparency for international payments. It enables banks and customers to track payments end-to-end with greater visibility and faster processing times.

3. **SWIFT MT900/MT910:**
    - **Confirmation Messages:** MT900 is a confirmation of debit, and MT910 is a confirmation of credit. These messages help confirm the successful execution of transactions.

#### **Troubleshooting Transactions:**

1. **Identifying Issues:**
    - **Incorrect Details:** Common issues include incorrect account numbers, SWIFT/BIC codes, or currency details.
    - **Compliance and Regulations:** Transactions may be delayed or rejected due to compliance issues or regulatory requirements.

2. **Communication:**
    - **Contacting Banks:** The sender or recipient can contact their respective banks to resolve issues or obtain status updates. Banks will use SWIFT messages to communicate with each other regarding the issue.

3. **SWIFT Network Logs:**
    - **Message Logs:** Banks can access SWIFT network logs to review message histories and identify any discrepancies or issues in the transaction process.

4. **Dispute Resolution:**
    - **Involvement of Correspondent Banks:** If intermediary banks are involved, they may also need to be contacted to resolve issues or clarify transaction details.

5. **Correction and Resubmission:**
    - **Amendments:** If an error is identified, a new SWIFT message may need to be sent to correct the details. This involves sending a new transaction instruction or an amendment message.

### **Summary**

SWIFT is a global messaging network that facilitates secure communication between banks for international wire transfers. It standardizes the format and transmission of payment instructions but does not handle the actual transfer of funds. SWIFT messages, such as MT103 and MT202, carry transaction details, and the SWIFT gpi system enhances tracking and transparency. Tracking transactions involves using reference numbers and SWIFT gpi, while troubleshooting requires contacting banks, reviewing message logs, and correcting any errors through resubmission or amendment.

### Sample Message

SWIFT messages are standardized formats used to communicate financial transactions and instructions between banks and financial institutions. Each SWIFT message is composed of several fields and follows a specific format. Here’s a sample SWIFT message and an explanation of its components:

### **Sample SWIFT Message**

Here’s a simplified example of a SWIFT MT103 message, which is used for customer credit transfers:

```plaintext
{1:F01BANKUS33AXXX0000000000}{2:I103BANKGB33XXX0000000000}{3:{108:ABC123456}}{4:
:20:ABC123456
:23B:CRED
:32A:230828USD1000,
:33B:USD1000,
:50K:/123456789
John Doe
123 Main St
New York, NY 10001
:59:/987654321
Jane Smith
456 Elm St
London, UK EC1A 1BB
:70:Invoice 1234
:71A:OUR
:72:/ACC/987654321
-}
```

### **Explanation of SWIFT MT103 Message Components**

1. **Basic Header (Block 1):**
    - `{1:F01BANKUS33AXXX0000000000}`
    - **F01:** Indicates that this is a FIN message (the standard SWIFT message type).
    - **BANKUS33A:** The SWIFT/BIC code of the sending bank (Bank US, New York).
    - **XXX0000000000:** Message sequence number (for internal use).

2. **Application Header (Block 2):**
    - `{2:I103BANKGB33XXX0000000000}`
    - **I103:** Message type (MT103, customer credit transfer).
    - **BANKGB33:** The SWIFT/BIC code of the receiving bank (Bank GB, London).
    - **XXX0000000000:** Message sequence number (for internal use).

3. **User Header (Block 3):**
    - `{3:{108:ABC123456}}`
    - **108:** Transaction reference number (ABC123456) for tracking purposes.

4. **Text Block (Block 4):**
    - This block contains the actual transaction details and instructions.

    - **:20:ABC123456**
        - **20:** Transaction reference number (ABC123456).

    - **:23B:CRED**
        - **23B:** Transaction type code (CRED for credit transfer).

    - **:32A:230828USD1000,**
        - **32A:** Value date, currency, and amount.
        - **230828:** Value date (August 28, 2023).
        - **USD:** Currency (U.S. Dollar).
        - **1000,:** Amount (1,000.00 USD).

    - **:33B:USD1000,**
        - **33B:** Currency and amount in the currency of the transaction (1,000.00 USD).

    - **:50K:/123456789 John Doe 123 Main St New York, NY 10001**
        - **50K:** Ordering customer details.
        - **/123456789:** Account number.
        - **John Doe:** Account holder's name.
        - **123 Main St New York, NY 10001:** Address.

    - **:59:/987654321 Jane Smith 456 Elm St London, UK EC1A 1BB**
        - **59:** Beneficiary customer details.
        - **/987654321:** Account number.
        - **Jane Smith:** Beneficiary's name.
        - **456 Elm St London, UK EC1A 1BB:** Address.

    - **:70:Invoice 1234**
        - **70:** Remittance information or additional details about the transaction (e.g., invoice number).

    - **:71A:OUR**
        - **71A:** Charges code (OUR indicates that the sender pays all charges).

    - **:72:/ACC/987654321**
        - **72:** Additional information or special instructions (e.g., account number for further credit).

5. **Trailer (Block 5):**
    - `-}`
    - Indicates the end of the SWIFT message.

### **Key Points to Note**

- **Field Codes:** SWIFT messages use standardized field codes (e.g., :20:, :32A:) to define the type of information provided.
- **Formatting:** The message structure includes headers, application blocks, text blocks, and trailers, all following specific formats to ensure consistency and clarity.
- **Security and Validation:** SWIFT messages are transmitted securely via the SWIFT network, and the information within the messages is validated according to predefined rules to ensure accuracy and prevent errors.

### **Summary**

The SWIFT MT103 message is a standardized format used for customer credit transfers. It includes essential details such as transaction reference numbers, value dates, amounts, and both the sender's and recipient's information. The message is structured in blocks, with headers, application data, and transaction details clearly defined to facilitate secure and accurate international wire transfers.

### ISO 20022

**ISO 20022** is an international standard for electronic data interchange between financial institutions. It is used to define messages for various financial services, including payments, securities, trade services, and more. The standard is designed to replace older messaging formats such as ISO 15022 (used for securities) and SWIFT MT (used for payments). It provides a more comprehensive and flexible framework for financial messaging, facilitating interoperability and improving the efficiency of financial transactions.

### **Overview of ISO 20022**

**ISO 20022** offers several advantages over previous standards:

1. **Rich Data:** It allows for richer, more detailed messages with structured and standardized data fields.
2. **Flexibility:** Supports a wide range of financial services and transaction types.
3. **Interoperability:** Enhances communication between different financial institutions and systems globally.
4. **XML Format:** Utilizes XML (eXtensible Markup Language) for messages, which is more versatile and easier to process compared to older formats.

### **ISO 20022 and SWIFT**

**SWIFT** (Society for Worldwide Interbank Financial Telecommunication) is adopting ISO 20022 as part of its strategy to modernize and enhance its messaging infrastructure. This transition is intended to improve the efficiency and clarity of financial messaging.

#### **SWIFT ISO 20022 Migration**

- **Background:** SWIFT has been gradually migrating from the older MT (Message Type) format to ISO 20022. This transition is aimed at improving data quality and providing more detailed information for payments.

- **Timeline:** The migration to ISO 20022 for SWIFT's payment messages started in November 2022 and is expected to be completed by November 2025. This phased approach ensures that financial institutions have time to adapt to the new standard.

- **Key Benefits:**
    - **Enhanced Data:** ISO 20022 provides more detailed information, which helps in reducing errors and improving compliance with regulations.
    - **Improved Reconciliation:** The richer data content aids in better transaction reconciliation and reduces the need for manual intervention.
    - **Standardization:** A unified standard across various financial products and services enhances interoperability between different systems and institutions.

### **Structure of ISO 20022 Messages**

ISO 20022 messages are structured in a way that provides comprehensive details about financial transactions. The structure includes several components:

1. **Message Header:**
    - **Identification:** Unique message identifiers, timestamps, and sender/receiver information.
    - **Example:** `<Header><MessageId>1234567890</MessageId><CreationDateTime>2024-08-28T15:30:00</CreationDateTime></Header>`

2. **Business Application Header (BAH):**
    - **Purpose:** Contains business-specific details and instructions for processing the message.
    - **Example:** `<BusinessApplicationHeader><MessageType>Payment</MessageType></BusinessApplicationHeader>`

3. **Message Body:**
    - **Content:** Detailed information about the financial transaction, such as payment instructions, beneficiary details, and transaction amounts.
    - **Example:** `<PaymentInformation><PaymentMethod>CreditTransfer</PaymentMethod><Amount>1000.00</Amount><Currency>USD</Currency></PaymentInformation>`

4. **Trailer:**
    - **End of Message:** Marks the end of the message and may include checksums or control information.
    - **Example:** `<Trailer><Checksum>abcdef123456</Checksum></Trailer>`

### **Example of an ISO 20022 Payment Message**

Here is a simplified example of an ISO 20022 payment message in XML format:

```xml
<Document>
    <CstmrCdtTrfInitn>
        <GrpHdr>
            <MsgId>1234567890</MsgId>
            <CreDtTm>2024-08-28T15:30:00</CreDtTm>
            <NbOfTxs>1</NbOfTxs>
            <CtrlSum>1000.00</CtrlSum>
            <InitgPty>
                <Nm>John Doe</Nm>
            </InitgPty>
        </GrpHdr>
        <PmtInf>
            <PmtInfId>PMT20240828</PmtInfId>
            <PmtMtd>TRF</PmtMtd>
            <NbOfTxs>1</NbOfTxs>
            <CtrlSum>1000.00</CtrlSum>
            <PmtTpInf>
                <CtgyPurp>
                    <Cd>PAYM</Cd>
                </CtgyPurp>
            </PmtTpInf>
            <ReqdExctnDt>2024-08-29</ReqdExctnDt>
            <Dbtr>
                <Nm>John Doe</Nm>
                <PstlAdr>
                    <Ctry>US</Ctry>
                    <AdrLine>123 Main St</AdrLine>
                    <AdrLine>New York, NY 10001</AdrLine>
                </PstlAdr>
            </Dbtr>
            <DbtrAcct>
                <Id>
                    <IBAN>US123456789012345678901234</IBAN>
                </Id>
            </DbtrAcct>
            <DbtrAgt>
                <FinInstnId>
                    <BIC>BANKUS33</BIC>
                </FinInstnId>
            </DbtrAgt>
            <CdtTrfTxInf>
                <PmtId>
                    <EndToEndId>TRX123456</EndToEndId>
                </PmtId>
                <Amt>
                    <InstdAmt Ccy="USD">1000.00</InstdAmt>
                </Amt>
                <CdtrAgt>
                    <FinInstnId>
                        <BIC>BANKGB33</BIC>
                    </FinInstnId>
                </CdtrAgt>
                <Cdtr>
                    <Nm>Jane Smith</Nm>
                    <PstlAdr>
                        <Ctry>GB</Ctry>
                        <AdrLine>456 Elm St</AdrLine>
                        <AdrLine>London, UK EC1A 1BB</AdrLine>
                    </PstlAdr>
                </Cdtr>
                <CdtrAcct>
                    <Id>
                        <IBAN>GB987654321098765432109876</IBAN>
                    </Id>
                </CdtrAcct>
            </CdtTrfTxInf>
        </PmtInf>
    </CstmrCdtTrfInitn>
</Document>
```

### **Explanation of the Example**

- **Document:** The root element for the message.
- **CstmrCdtTrfInitn:** Customer Credit Transfer Initiation, indicating that this is a payment initiation message.
- **GrpHdr:** Group Header containing general information about the message.
    - **MsgId:** Unique message identifier.
    - **CreDtTm:** Creation date and time of the message.
    - **NbOfTxs:** Number of transactions included.
    - **CtrlSum:** Control sum of the total amount.
    - **InitgPty:** Initiating party (sender’s details).
- **PmtInf:** Payment Information containing details specific to the payment.
    - **PmtInfId:** Payment Information Identifier.
    - **PmtMtd:** Payment method (Transfer).
    - **PmtTpInf:** Payment type information (e.g., category purpose).
    - **Dbtr:** Debtor (payer’s details).
    - **DbtrAcct:** Debtor account details.
    - **DbtrAgt:** Debtor’s agent (payer’s bank details).
    - **CdtTrfTxInf:** Credit Transfer Transaction Information.
        - **PmtId:** Payment Identifier.
        - **Amt:** Amount and currency.
        - **CdtrAgt:** Creditor’s agent (receiver’s bank details).
        - **Cdtr:** Creditor (recipient’s details).
        - **CdtrAcct:** Creditor account details.

### **Summary**

ISO 20022 is a modern, comprehensive standard for financial messaging that offers richer data and greater flexibility compared to older standards. SWIFT is adopting ISO 20022 to enhance its messaging capabilities, providing better data quality and interoperability for international transactions. The standard uses XML format for message definitions and is designed to support various financial services beyond payments.

To illustrate the flow of domestic wire transfers within a financial system using Mermaid.js, you can create a flowchart that visually represents the steps and interactions involved in processing a domestic wire transfer. Here’s a detailed example of how to represent this process in Mermaid.js:

### **Mermaid.js Flowchart for Domestic Wire Transfers**

```mermaid
flowchart TD
    A[Customer Initiates Wire Transfer] --> B[Bank A Processes Wire Transfer Request]
    B --> C[Bank A Sends Wire Transfer to Fedwire/CHIPS]
    C --> D[Federal Reserve/CHIPS Processes Transfer]
    D --> E[Bank B Receives Transfer Instructions]
    E --> F[Bank B Credits Receiver's Account]
    F --> G[Transaction Complete]

    classDef process fill:#f9f,stroke:#333,stroke-width:2px;
    class A,B,C,D,E,F process;
    
    classDef startend fill:#bbf,stroke:#333,stroke-width:2px;
    class A,G startend;
    
    classDef intermediary fill:#fbb,stroke:#333,stroke-width:2px;
    class B,C,D,E intermediate;
```

### **Explanation of the Flowchart**

1. **Customer Initiates Wire Transfer (A)**
    - The process begins when a customer requests a wire transfer through their bank.

2. **Bank A Processes Wire Transfer Request (B)**
    - Bank A receives the wire transfer request from the customer and begins processing it. This includes verifying the request, checking account details, and preparing the transaction for submission.

3. **Bank A Sends Wire Transfer to Fedwire/CHIPS (C)**
    - Bank A submits the wire transfer request to a wire transfer system like Fedwire or CHIPS. These systems handle the settlement of funds between banks.

4. **Federal Reserve/CHIPS Processes Transfer (D)**
    - The Federal Reserve’s Fedwire system or the Clearing House Interbank Payments System (CHIPS) processes the transfer, ensuring the funds are moved from Bank A to Bank B.

5. **Bank B Receives Transfer Instructions (E)**
    - Bank B receives the wire transfer instructions from the Fedwire or CHIPS system.

6. **Bank B Credits Receiver's Account (F)**
    - Bank B processes the received funds and credits the receiver’s account accordingly.

7. **Transaction Complete (G)**
    - The wire transfer process is complete, and the receiver’s account has been credited with the transferred amount.

### **Styling and Classes**

- **`process` Class:** Applied to all nodes involved in the core processing steps. This class uses a magenta fill color.
- **`startend` Class:** Applied to the start (Customer Initiates Wire Transfer) and end (Transaction Complete) nodes. This class uses a blue fill color to denote the start and end points.
- **`intermediate` Class:** Applied to intermediate steps involving interactions between banks and the wire transfer system. This class uses a red fill color.

### **Mermaid.js Diagram Syntax**

- **`flowchart TD`**: Defines a top-down flowchart.
- **`A[Customer Initiates Wire Transfer] --> B[Bank A Processes Wire Transfer Request]`**: Specifies the flow from one node to another.
- **`classDef`**: Defines styling for different classes of nodes.

This Mermaid.js diagram provides a clear visualization of the domestic wire transfer process, showing each step and the flow of information between entities involved.

To represent the flow of international wire transfers between banks in a swimlane diagram using Mermaid.js, you'll need to use the "swimlane" feature of Mermaid.js, which organizes processes into lanes to indicate the various participants or systems involved.

Here’s a detailed Mermaid.js swimlane diagram that illustrates how an international wire transfer happens between banks:

### **Mermaid.js Swimlane Diagram for International Wire Transfers**

```mermaid
%%{ init : { "theme" : "default" } }%%
swimlaneDiagram
    %% Define the lanes
    participant Customer
    participant Bank A
    participant SWIFT Network
    participant Bank B

    %% Define the flow of the wire transfer
    Customer -> Bank A: Initiates International Wire Transfer
    Bank A -> SWIFT Network: Sends Wire Transfer Request
    SWIFT Network -> Bank B: Routes Transfer Instructions
    Bank B -> SWIFT Network: Acknowledges Receipt of Transfer
    SWIFT Network -> Bank A: Confirms Transfer Completion
    Bank A -> Customer: Notifies Transfer Completion
    Bank B -> Customer: Credits Receiver’s Account

    %% Optional: Add styling to the diagram
    classDef default fill:#f9f,stroke:#333,stroke-width:2px;
    classDef participant fill:#bbf,stroke:#333,stroke-width:2px;
    class Customer,Bank A,Bank B participant;
    class SWIFT Network default;
```

### **Explanation of the Swimlane Diagram**

- **Lanes:**
    - **Customer:** The individual or entity initiating the wire transfer.
    - **Bank A:** The sender's bank, which processes the wire transfer request.
    - **SWIFT Network:** The international network that routes wire transfer instructions.
    - **Bank B:** The recipient's bank, which receives the transfer and credits the recipient’s account.

- **Flow Steps:**
    1. **Customer Initiates International Wire Transfer:**
        - The process starts when the customer requests an international wire transfer from Bank A.

    2. **Bank A Sends Wire Transfer Request:**
        - Bank A processes the request and sends the transfer instructions through the SWIFT Network.

    3. **SWIFT Network Routes Transfer Instructions:**
        - The SWIFT Network routes the transfer instructions from Bank A to Bank B.

    4. **Bank B Acknowledges Receipt of Transfer:**
        - Bank B receives the instructions and acknowledges receipt through the SWIFT Network.

    5. **SWIFT Network Confirms Transfer Completion:**
        - The SWIFT Network sends confirmation of the transfer completion back to Bank A.

    6. **Bank A Notifies Transfer Completion:**
        - Bank A notifies the customer that the wire transfer is complete.

    7. **Bank B Credits Receiver’s Account:**
        - Bank B processes the received funds and credits the receiver’s account.

### **Styling and Classes**

- **`participant` Class:** Applied to the lanes (Customer, Bank A, Bank B) and uses a light blue fill color.
- **`default` Class:** Applied to the SWIFT Network node and uses a default fill color.

### **Mermaid.js Diagram Syntax**

- **`swimlaneDiagram`**: Defines a swimlane diagram.
- **`participant`**: Specifies each lane or participant in the diagram.
- **`->`**: Indicates the flow of the process between participants.

This Mermaid.js swimlane diagram provides a clear visualization of the steps and interactions involved in processing an international wire transfer, highlighting the roles of different entities in the process.