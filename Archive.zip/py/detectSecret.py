import os
import yaml
from detect_secrets import SecretsCollection
from detect_secrets.settings import default_settings

def detect_secrets_in_yaml(folder_path):
    secrets_collection = SecretsCollection()
    
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            if file.endswith(('.yml', '.yaml')):
                file_path = os.path.join(root, file)
                
                # Scan the file for secrets
                secrets_collection.scan_file(file_path)
                
                # Load and parse YAML content
                with open(file_path, 'r') as yaml_file:
                    try:
                        yaml_content = yaml.safe_load(yaml_file)
                        
                        # Check for potential plain text secrets in YAML content
                        check_yaml_for_secrets(file_path, yaml_content)
                    except yaml.YAMLError as e:
                        print(f"Error parsing YAML file {file_path}: {e}")

    # Print detected secrets
    for potential_secret in secrets_collection:
        print(f"Potential secret found in {potential_secret.filename} on line {potential_secret.line_number}")

def check_yaml_for_secrets(file_path, yaml_content, parent_key=''):
    if isinstance(yaml_content, dict):
        for key, value in yaml_content.items():
            new_key = f"{parent_key}.{key}" if parent_key else key
            if isinstance(value, (dict, list)):
                check_yaml_for_secrets(file_path, value, new_key)
            elif isinstance(value, str) and len(value) > 0:
                if any(keyword in new_key.lower() for keyword in ['password', 'secret', 'key', 'token', 'api' , 'pwd' , 'pass' , 'cred' , 'clientSecret' , 'client_secret' , 'client-secret' ]):
                    print(f"Potential plain text secret found in {file_path}: {new_key}")
    elif isinstance(yaml_content, list):
        for index, item in enumerate(yaml_content):
            new_key = f"{parent_key}[{index}]"
            check_yaml_for_secrets(file_path, item, new_key)

if __name__ == "__main__":
    folder_path = input("Enter the folder path to scan for YAML files: ")
    if os.path.isdir(folder_path):
        detect_secrets_in_yaml(folder_path)
    else:
        print(f"Error: {folder_path} is not a valid directory.")