import os
import strictyaml

def validate_yaml_files(directory):
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith(('.yml', '.yaml')):
                file_path = os.path.join(root, file)
                try:
                    with open(file_path, 'r') as yaml_file:
                        content = yaml_file.read()
                        strictyaml.load(content)
                    print(f"Valid YAML: {file_path}")
                except strictyaml.exceptions.YAMLValidationError as e:
                    print(f"Invalid YAML: {file_path}")
                    print(f"Error: {str(e)}")
                except Exception as e:
                    print(f"Error reading file {file_path}: {str(e)}")

if __name__ == "__main__":
    directory = input("Enter the directory to validate YAML files: ")
    if os.path.exists(directory):
        validate_yaml_files(directory)
    else:
        print("Error: The specified directory does not exist or is unknown.")

