import os
import shutil

def organize_files(directory):
    for root, dirs, files in os.walk(directory):
        for file in files:
            file_path = os.path.join(root, file)
            file_extension = os.path.splitext(file)[1]
            if file_extension:
                destination_folder = os.path.join(directory, file_extension[1:])
                os.makedirs(destination_folder, exist_ok=True)
                shutil.move(file_path, os.path.join(destination_folder, file))

if __name__ == "__main__":
    directory = input("Enter the directory to organize the files: ")
    if os.path.exists(directory):
        organize_files(directory)
        print("Files organized successfully.")
    else:
        print("Error: The specified directory does not exist or is unknown.")