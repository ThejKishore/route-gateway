import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.stream.Stream;

public class FileOrganizer {

    public static void organizeFiles(Path directory) throws IOException {
        if (!Files.isDirectory(directory)) {
            throw new IllegalArgumentException(directory + " is not a valid directory.");
        }

        try (Stream<Path> paths = Files.walk(directory)) {
            paths.filter(Files::isRegularFile).forEach(filePath -> {
                try {
                    String fileExtension = getFileExtension(filePath);
                    Path destinationFolder = fileExtension.isEmpty() ?
                            directory.resolve("no_extension") :
                            directory.resolve(fileExtension);

                    if (!Files.exists(destinationFolder)) {
                        Files.createDirectory(destinationFolder);
                    }

                    Path destinationFile = destinationFolder.resolve(filePath.getFileName());
                    Files.move(filePath, destinationFile, StandardCopyOption.REPLACE_EXISTING);
                } catch (IOException e) {
                    System.err.println("Error moving file " + filePath + ": " + e.getMessage());
                }
            });
        }
    }

    private static String getFileExtension(Path filePath) {
        String fileName = filePath.getFileName().toString();
        int dotIndex = fileName.lastIndexOf('.');
        return (dotIndex == -1) ? "" : fileName.substring(dotIndex + 1);
    }

    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage: java FileOrganizer <directory>");
            return;
        }

        Path directory = Paths.get(args[0]);

        try {
            organizeFiles(directory);
            System.out.println("Files organized successfully.");
        } catch (IllegalArgumentException | IOException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
