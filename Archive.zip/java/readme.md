
[ghooks.gradle](https://github.com/gtramontina/ghooks.gradle)

## What
Share and version-control all your git hooks. This plugin is a Gradle version of ghooks for Node.js.

### Installing
Add the following entry to your build.gradle on the plugins section.

```groovy
plugins {
    id "com.gtramontina.ghooks.gradle" version "2.0.0"
}
```

`build.gradle`

Next, create a .githooks/ directory on the root of your git project. This is where you'll keep your git hooks:

mkdir .githooks/
You may now execute any gradle command. The plugin will ensure it has everything it needs in order to get your git hooks working.

With additions to your build file, you can even use this plugin if your hooks are in a dependency and shared amongst multiple projects:

```groovy
task addHooksFromJar {
    def hookDir = new File(projectDir, ".githooks")

    if(!hookDir.exists()) {
        hookDir.mkdir()
    }

    configurations.compile.each { jar ->
        if (jar.name.contains("hooks")) {
            copy {
                from(zipTree(jar))
                into(hookDir)
            }
        }
    }
}
```
`build.gradle`

```groovy
installGitHooks.dependsOn("addHooksFromJar")
```

`build.gradle`

## Contributing
Contributions of any kind are very welcome! 🙏

