package com.example;

import org.gradle.api.DefaultTask;
import org.gradle.api.tasks.InputDirectory;
import org.gradle.api.tasks.TaskAction;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.error.YamlException;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;
import java.util.regex.Pattern;

public class SecretDetectorTask extends DefaultTask {

    @InputDirectory
    private Path directory;

    private static final Set<String> SECRET_KEYWORDS = Set.of("password", "secret", "key", "token", "api" , "pwd" , "pass" ,"cred" , "clientSecret" , "client_secret" , "client-secret" );
    private static final List<Pattern> IGNORED_PATTERNS = List.of(
        Pattern.compile("\\$\\{\\w+\\}"),
        Pattern.compile("\\{env\\}/\\w+"),
        Pattern.compile("\\{bcrypt\\}/\\w+")
    );

    @TaskAction
    public void detectSecrets() throws IOException {
        if (!Files.isDirectory(directory)) {
            throw new IllegalArgumentException(directory + " is not a valid directory.");
        }

        Files.walkFileTree(directory, new SimpleFileVisitor<Path>() {
            @Override
            public FileVisitResult visitFile(Path filePath, BasicFileAttributes attrs) throws IOException {
                if (Files.isRegularFile(filePath)) {
                    String fileName = filePath.toString().toLowerCase();

                    if (fileName.endsWith(".yml") || fileName.endsWith(".yaml")) {
                        // Process YAML files
                        processYamlFile(filePath);
                    } else if (fileName.endsWith(".properties")) {
                        // Process .properties files
                        processPropertiesFile(filePath);
                    }
                }
                return FileVisitResult.CONTINUE;
            }
        });
    }

    private void processYamlFile(Path filePath) throws IOException {
        try {
            String content = Files.readString(filePath);
            Yaml yaml = new Yaml();
            Object yamlContent = yaml.load(content);

            // Check for potential plain text secrets in YAML content
            checkYamlForSecrets(filePath, yamlContent, "");
        } catch (YamlException e) {
            System.out.println("Error parsing YAML file " + filePath + ": " + e.getMessage());
        }
    }

    private void processPropertiesFile(Path filePath) throws IOException {
        try {
            List<String> lines = Files.readAllLines(filePath);

            for (String line : lines) {
                if (line.contains("=")) {
                    String[] parts = line.split("=", 2);
                    if (parts.length == 2) {
                        String key = parts[0].trim();
                        String value = parts[1].trim();

                        // Ignore keys or values matching ignored patterns
                        if (!isIgnoredPattern(value)) {
                            // Check for potential plain text secrets in properties file
                            if (SECRET_KEYWORDS.stream().anyMatch(keyword -> key.toLowerCase().contains(keyword) || value.toLowerCase().contains(keyword))) {
                                System.out.println("Potential plain text secret found in " + filePath + ": " + key + " = " + value);
                            }
                        }
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading properties file " + filePath + ": " + e.getMessage());
        }
    }

    private void checkYamlForSecrets(Path filePath, Object yamlContent, String parentKey) {
        if (yamlContent instanceof Map<?, ?>) {
            Map<?, ?> map = (Map<?, ?>) yamlContent;
            map.forEach((key, value) -> {
                String newKey = parentKey.isEmpty() ? key.toString() : parentKey + "." + key;
                if (!isIgnoredPattern(value)) {
                    checkYamlForSecrets(filePath, value, newKey);
                }
            });
        } else if (yamlContent instanceof List<?>) {
            List<?> list = (List<?>) yamlContent;
            for (int i = 0; i < list.size(); i++) {
                String newKey = parentKey + "[" + i + "]";
                if (!isIgnoredPattern(newKey)) {
                    checkYamlForSecrets(filePath, list.get(i), newKey);
                }
            }
        } else if (yamlContent instanceof String) {
            String value = (String) yamlContent;
            if (!value.isEmpty() && !isIgnoredPattern(value) && SECRET_KEYWORDS.stream().anyMatch(keyword -> parentKey.toLowerCase().contains(keyword))) {
                System.out.println("Potential plain text secret found in " + filePath + ": " + parentKey);
            }
        }
    }

    private boolean isIgnoredPattern(String text) {
        return IGNORED_PATTERNS.stream().anyMatch(pattern -> pattern.matcher(text).find());
    }

    public void setDirectory(Path directory) {
        this.directory = directory;
    }
}
