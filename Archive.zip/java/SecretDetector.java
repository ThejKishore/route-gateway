import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.error.YamlException;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SecretDetector {

    private static final Logger LOGGER = Logger.getLogger(SecretDetector.class.getName());
    private static final Set<String> SECRET_KEYWORDS = Set.of("password", "secret", "key", "token", "api" , "pwd" , "pass" ,"cred" , "clientSecret" , "client_secret" , "client-secret" );

    public static void detectSecretsInYaml(Path folderPath) throws IOException {
        if (!Files.isDirectory(folderPath)) {
            throw new IllegalArgumentException(folderPath + " is not a valid directory.");
        }

        Files.walkFileTree(folderPath, new SimpleFileVisitor<Path>() {
            @Override
            public FileVisitResult visitFile(Path filePath, BasicFileAttributes attrs) throws IOException {
                if (Files.isRegularFile(filePath) && (filePath.toString().endsWith(".yml") || filePath.toString().endsWith(".yaml"))) {
                    // Load and parse YAML content
                    try {
                        String content = Files.readString(filePath);
                        Yaml yaml = new Yaml();
                        Object yamlContent = yaml.load(content);

                        // Check for potential plain text secrets in YAML content
                        checkYamlForSecrets(filePath, yamlContent);
                    } catch (YamlException e) {
                        System.out.println("Error parsing YAML file " + filePath + ": " + e.getMessage());
                    }
                }
                return FileVisitResult.CONTINUE;
            }
        });
    }

    private static void checkYamlForSecrets(Path filePath, Object yamlContent, String parentKey) {
        if (yamlContent instanceof Map<?, ?>) {
            Map<?, ?> map = (Map<?, ?>) yamlContent;
            map.forEach((key, value) -> {
                String newKey = parentKey.isEmpty() ? key.toString() : parentKey + "." + key;
                checkYamlForSecrets(filePath, value, newKey);
            });
        } else if (yamlContent instanceof List<?>) {
            List<?> list = (List<?>) yamlContent;
            for (int i = 0; i < list.size(); i++) {
                String newKey = parentKey + "[" + i + "]";
                checkYamlForSecrets(filePath, list.get(i), newKey);
            }
        } else if (yamlContent instanceof String) {
            String value = (String) yamlContent;
            if (!value.isEmpty() && SECRET_KEYWORDS.stream().anyMatch(keyword -> parentKey.toLowerCase().contains(keyword))) {
                System.out.println("Potential plain text secret found in " + filePath + ": " + parentKey);
            }
        }
    }

    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage: java SecretDetector <directory>");
            return;
        }

        Path folderPath = Paths.get(args[0]);

        try {
            detectSecretsInYaml(folderPath);
        } catch (IllegalArgumentException | IOException e) {
            LOGGER.log(Level.SEVERE, "Error: " + e.getMessage(), e);
        }
    }
}
