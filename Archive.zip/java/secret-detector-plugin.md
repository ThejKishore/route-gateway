To include the `YamlValidator.java` code as part of the Gradle plugin project, you will need to:

1. **Combine the secret detection and YAML validation functionalities** into a single Gradle plugin.
2. **Implement the YAML validation logic** as a part of the plugin tasks.

Here's how you can integrate the YAML validation functionality into your existing Gradle plugin:

### Updated Java Code for Plugin

#### 1. Update the Plugin Code

Combine both functionalities into a single Gradle plugin project. This involves adding the `YamlValidator` class to the plugin and updating the plugin implementation.

**Plugin Structure:**

- **SecretDetectorPlugin.java**: The main plugin implementation.
- **SecretDetectorTask.java**: The task for detecting secrets.
- **YamlValidator.java**: The task for validating YAML files.

**File: `src/main/java/com/example/SecretDetectorPlugin.java`**

```java
package com.example;

import org.gradle.api.Plugin;
import org.gradle.api.Project;
import org.gradle.api.tasks.TaskContainer;
import org.gradle.api.tasks.TaskProvider;

public class SecretDetectorPlugin implements Plugin<Project> {

    @Override
    public void apply(Project project) {
        TaskContainer tasks = project.getTasks();

        // Register secret detection task
        TaskProvider<SecretDetectorTask> detectSecretsTask = tasks.register("detectSecrets", SecretDetectorTask.class);
        
        // Register YAML validation task
        TaskProvider<YamlValidatorTask> validateYamlTask = tasks.register("validateYaml", YamlValidatorTask.class);
    }
}
```

**File: `src/main/java/com/example/SecretDetectorTask.java`**

```java
package com.example;

import org.gradle.api.DefaultTask;
import org.gradle.api.tasks.InputDirectory;
import org.gradle.api.tasks.TaskAction;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.error.YamlException;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;

public class SecretDetectorTask extends DefaultTask {

    @InputDirectory
    private Path directory;

    private static final Set<String> SECRET_KEYWORDS = Set.of("password", "secret", "key", "token", "api");

    @TaskAction
    public void detectSecrets() throws IOException {
        if (!Files.isDirectory(directory)) {
            throw new IllegalArgumentException(directory + " is not a valid directory.");
        }

        Files.walkFileTree(directory, new SimpleFileVisitor<Path>() {
            @Override
            public FileVisitResult visitFile(Path filePath, BasicFileAttributes attrs) throws IOException {
                if (Files.isRegularFile(filePath) && (filePath.toString().endsWith(".yml") || filePath.toString().endsWith(".yaml"))) {
                    // Load and parse YAML content
                    try {
                        String content = Files.readString(filePath);
                        Yaml yaml = new Yaml();
                        Object yamlContent = yaml.load(content);

                        // Check for potential plain text secrets in YAML content
                        checkYamlForSecrets(filePath, yamlContent, "");
                    } catch (YamlException e) {
                        System.out.println("Error parsing YAML file " + filePath + ": " + e.getMessage());
                    }
                }
                return FileVisitResult.CONTINUE;
            }
        });
    }

    private void checkYamlForSecrets(Path filePath, Object yamlContent, String parentKey) {
        if (yamlContent instanceof Map<?, ?>) {
            Map<?, ?> map = (Map<?, ?>) yamlContent;
            map.forEach((key, value) -> {
                String newKey = parentKey.isEmpty() ? key.toString() : parentKey + "." + key;
                checkYamlForSecrets(filePath, value, newKey);
            });
        } else if (yamlContent instanceof List<?>) {
            List<?> list = (List<?>) yamlContent;
            for (int i = 0; i < list.size(); i++) {
                String newKey = parentKey + "[" + i + "]";
                checkYamlForSecrets(filePath, list.get(i), newKey);
            }
        } else if (yamlContent instanceof String) {
            String value = (String) yamlContent;
            if (!value.isEmpty() && SECRET_KEYWORDS.stream().anyMatch(keyword -> parentKey.toLowerCase().contains(keyword))) {
                System.out.println("Potential plain text secret found in " + filePath + ": " + parentKey);
            }
        }
    }

    public void setDirectory(Path directory) {
        this.directory = directory;
    }
}
```

**File: `src/main/java/com/example/YamlValidatorTask.java`**

```java
package com.example;

import org.gradle.api.DefaultTask;
import org.gradle.api.tasks.InputDirectory;
import org.gradle.api.tasks.TaskAction;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.error.YamlException;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;

public class YamlValidatorTask extends DefaultTask {

    @InputDirectory
    private Path directory;

    @TaskAction
    public void validateYamlFiles() throws IOException {
        if (!Files.isDirectory(directory)) {
            throw new IllegalArgumentException(directory + " is not a valid directory.");
        }

        Files.walkFileTree(directory, new SimpleFileVisitor<Path>() {
            @Override
            public FileVisitResult visitFile(Path filePath, BasicFileAttributes attrs) throws IOException {
                if (Files.isRegularFile(filePath) && (filePath.toString().endsWith(".yml") || filePath.toString().endsWith(".yaml"))) {
                    // Load and parse YAML content
                    try {
                        String content = Files.readString(filePath);
                        Yaml yaml = new Yaml();
                        yaml.load(content);
                        System.out.println("Valid YAML: " + filePath);
                    } catch (YamlException e) {
                        System.out.println("Invalid YAML: " + filePath);
                        System.out.println("Error: " + e.getMessage());
                    } catch (IOException e) {
                        System.out.println("Error reading file " + filePath + ": " + e.getMessage());
                    }
                }
                return FileVisitResult.CONTINUE;
            }
        });
    }

    public void setDirectory(Path directory) {
        this.directory = directory;
    }
}
```

### Step 3: Update `build.gradle`

Make sure your `build.gradle` is set up correctly to build and publish the plugin:

```gradle
plugins {
    id 'java-gradle-plugin'
}

repositories {
    mavenCentral()
}

dependencies {
    implementation gradleApi()
    implementation localGroovy()
    implementation 'org.yaml:snakeyaml:2.0'
}

gradlePlugin {
    plugins {
        secretDetector {
            id = 'com.example.secret-detector'
            implementationClass = 'com.example.SecretDetectorPlugin'
        }
    }
}
```

### Step 4: Publish or Test the Plugin

1. **Publish the Plugin Locally (for testing)**

   Publish the plugin to your local Maven repository:

   ```bash
   ./gradlew publishToMavenLocal
   ```

2. **Apply the Plugin in a Gradle Project**

   Apply the plugin in another Gradle project using the following configuration in `build.gradle`:

   ```gradle
   plugins {
       id 'com.example.secret-detector' version '1.0-SNAPSHOT'
   }

   detectSecrets {
       directory = file("src/main/resources") // Set the directory to scan for secrets
   }

   validateYaml {
       directory = file("src/main/resources") // Set the directory to validate YAML files
   }
   ```

### Full Directory Structure

```
secret-detector-plugin/
├── build.gradle
├── gradle.properties
├── gradlew
├── gradlew.bat
├── settings.gradle
├── src
│   └── main
│       ├── java
│       │   └── com
│       │       └── example
│       │           ├── SecretDetectorPlugin.java
│       │           ├── SecretDetectorTask.java
│       │           └── YamlValidatorTask.java
│       └── resources
```

### Summary

- **Plugin Implementation**: Combine secret detection and YAML validation into a single plugin.
- **Tasks**: Implement `SecretDetectorTask` and `YamlValidatorTask` for respective functionalities.
- **Usage**: Apply and configure the plugin in a Gradle project to use its tasks.

This approach allows you to integrate both functionalities into a single Gradle plugin, making it easier to manage and apply in your build process.