import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.error.YamlException;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.logging.Level;
import java.util.logging.Logger;

public class YamlValidator {

    private static final Logger LOGGER = Logger.getLogger(YamlValidator.class.getName());

    public static void validateYamlFiles(Path directory) throws IOException {
        if (!Files.isDirectory(directory)) {
            throw new IllegalArgumentException(directory + " is not a valid directory.");
        }

        Files.walkFileTree(directory, new SimpleFileVisitor<Path>() {
            @Override
            public FileVisitResult visitFile(Path filePath, BasicFileAttributes attrs) throws IOException {
                if (Files.isRegularFile(filePath) && (filePath.toString().endsWith(".yml") || filePath.toString().endsWith(".yaml"))) {
                    try {
                        String content = Files.readString(filePath);
                        Yaml yaml = new Yaml();
                        yaml.load(content);
                        System.out.println("Valid YAML: " + filePath);
                    } catch (YamlException e) {
                        System.out.println("Invalid YAML: " + filePath);
                        System.out.println("Error: " + e.getMessage());
                    } catch (IOException e) {
                        System.out.println("Error reading file " + filePath + ": " + e.getMessage());
                    }
                }
                return FileVisitResult.CONTINUE;
            }
        });
    }

    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage: java YamlValidator <directory>");
            return;
        }

        Path directory = Paths.get(args[0]);

        try {
            validateYamlFiles(directory);
        } catch (IllegalArgumentException | IOException e) {
            LOGGER.log(Level.SEVERE, "Error: " + e.getMessage(), e);
        }
    }
}
