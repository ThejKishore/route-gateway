# Create User Identity for Postgres

## Postgres
Below is a comprehensive solution involving Terraform to set up two user-managed identities with appropriate permissions for an Azure Database for PostgreSQL. Additionally, I'll provide a sample Java Spring Boot application to connect to PostgreSQL using one of the identities.

### Terraform Code

The Terraform code will create:
1. Two user-managed identities.
2. An Azure Database for PostgreSQL server.
3. RBAC role assignments for the managed identities.
4. A firewall rule to allow access to the database.

#### Terraform Configuration

```hcl
provider "azurerm" {
  features {}
}

# Variables
variable "resource_group_name" {
  default = "my-resource-group"
}

variable "location" {
  default = "East US"
}

variable "postgres_server_name" {
  default = "mypostgresserver"  # Must be globally unique
}

variable "postgres_admin_username" {
  default = "adminuser"
}

variable "postgres_admin_password" {
  default = "yourpasswordhere"  # Make sure to use a secure password
}

# Create Resource Group
resource "azurerm_resource_group" "example" {
  name     = var.resource_group_name
  location = var.location
}

# Create Azure Database for PostgreSQL Server
resource "azurerm_postgresql_server" "example" {
  name                = var.postgres_server_name
  resource_group_name = azurerm_resource_group.example.name
  location            = azurerm_resource_group.example.location
  sku_name            = "B_Gen5_1"
  storage_mb          = 5120
  version             = "12"
  administrator_login = var.postgres_admin_username
  administrator_login_password = var.postgres_admin_password

  # Ensure SSL is enforced
  ssl_enforcement = "Enabled"
}

# Create Managed Identity for Liquibase
resource "azurerm_user_assigned_identity" "liquibase_identity" {
  name                = "liquibase-identity"
  resource_group_name = azurerm_resource_group.example.name
  location            = azurerm_resource_group.example.location
}

# Create Managed Identity for Azure Container Apps
resource "azurerm_user_assigned_identity" "container_app_identity" {
  name                = "container-app-identity"
  resource_group_name = azurerm_resource_group.example.name
  location            = azurerm_resource_group.example.location
}

# Create Firewall Rule to allow access to the database
resource "azurerm_postgresql_server_firewall_rule" "allow_all" {
  name                = "allow-all"
  resource_group_name = azurerm_resource_group.example.name
  server_name         = azurerm_postgresql_server.example.name
  start_ip_address    = "0.0.0.0"
  end_ip_address      = "255.255.255.255"
}

# Assign Database Roles to Managed Identities
resource "azurerm_role_assignment" "liquibase_role" {
  principal_id   = azurerm_user_assigned_identity.liquibase_identity.principal_id
  role_definition_name = "Contributor"  # Adjust as needed for your use case
  scope          = azurerm_postgresql_server.example.id
}

resource "azurerm_role_assignment" "container_app_role" {
  principal_id   = azurerm_user_assigned_identity.container_app_identity.principal_id
  role_definition_name = "Contributor"  # Adjust as needed for your use case
  scope          = azurerm_postgresql_server.example.id
}

output "liquibase_identity_client_id" {
  value = azurerm_user_assigned_identity.liquibase_identity.client_id
}

output "container_app_identity_client_id" {
  value = azurerm_user_assigned_identity.container_app_identity.client_id
}
```

### Sample Java Spring Boot Application

This Java Spring Boot application uses the `com.azure:azure-identity` library to authenticate using the managed identity and connect to the PostgreSQL database.

#### Dependencies

Add the following dependencies to your `pom.xml`:

```xml
<dependencies>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-data-jpa</artifactId>
    </dependency>
    <dependency>
        <groupId>org.postgresql</groupId>
        <artifactId>postgresql</artifactId>
    </dependency>
    <dependency>
        <groupId>com.azure</groupId>
        <artifactId>azure-identity</artifactId>
        <version>1.6.0</version>
    </dependency>
    <!-- Other dependencies -->
</dependencies>
```

#### Application Configuration

Configure your `application.properties` file to use the managed identity:

```properties
spring.datasource.url=jdbc:postgresql://<your-postgres-server>.postgres.database.azure.com:5432/<your-database>
spring.datasource.username=<your-managed-identity-client-id>
spring.datasource.password=
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
```

#### Java Configuration

Create a configuration class to use the managed identity for authentication:

```java
import com.azure.identity.DefaultAzureCredentialBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;

@Configuration
public class DataSourceConfig {

    @Bean
    public DataSource dataSource() {
        // Configure the DataSource
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("org.postgresql.Driver");
        dataSource.setUrl("jdbc:postgresql://<your-postgres-server>.postgres.database.azure.com:5432/<your-database>");

        // Use DefaultAzureCredentialBuilder to authenticate with Managed Identity
        DefaultAzureCredentialBuilder builder = new DefaultAzureCredentialBuilder();
        dataSource.setUsername(builder.build().getToken().getToken()); // Use Managed Identity Client ID here
        dataSource.setPassword(""); // Managed Identity uses token-based authentication

        return dataSource;
    }
}
```

**Note:** The `DefaultAzureCredentialBuilder` will automatically pick up the managed identity credentials if running in Azure.

### Applying the Terraform Configuration

To apply the Terraform configuration:

1. Save the Terraform code to a file named `main.tf`.
2. Initialize Terraform:
   ```bash
   terraform init
   ```
3. Plan the deployment:
   ```bash
   terraform plan
   ```
4. Apply the configuration:
   ```bash
   terraform apply
   ```

**Ensure** to replace placeholders with actual values (e.g., `<your-postgres-server>`, `<your-database>`, and client IDs) and handle credentials securely.

This setup will create the necessary identities, configure PostgreSQL with appropriate roles, and provide a sample Spring Boot application for connecting to PostgreSQL using Azure Managed Identity.

Certainly! To use Liquibase with PostgreSQL and a managed identity, you need to set up a Liquibase changelog file in XML format to create a new schema and an `employee` table. Here’s a step-by-step guide:

### Liquibase Configuration

1. **Add Liquibase to Your Project**

   Add Liquibase dependencies to your `pom.xml`:

   ```xml
   <dependencies>
       <dependency>
           <groupId>org.liquibase</groupId>
           <artifactId>liquibase-core</artifactId>
           <version>4.19.0</version> <!-- Use the latest version -->
       </dependency>
       <dependency>
           <groupId>org.postgresql</groupId>
           <artifactId>postgresql</artifactId>
           <version>42.6.0</version>
       </dependency>
   </dependencies>
   ```

2. **Create Liquibase Changelog XML File**

   Create a file named `db-changelog.xml` in your resources directory (`src/main/resources`). This file will define the schema and table creation.

   ```xml
   <?xml version="1.0" encoding="UTF-8"?>
   <databaseChangeLog
       xmlns="http://www.liquibase.org/xml/ns/dbchangelog"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:schemaLocation="http://www.liquibase.org/xml/ns/dbchangelog
                           http://www.liquibase.org/xml/ns/dbchangelog/dbchangelog-3.8.xsd">

       <!-- ChangeSet to create a new schema -->
       <changeSet id="1" author="yourusername">
           <createSchema schemaName="myschema"/>
       </changeSet>

       <!-- ChangeSet to create a new table within the new schema -->
       <changeSet id="2" author="yourusername">
           <createTable tableName="employee" schemaName="myschema">
               <column name="id" type="serial">
                   <constraints primaryKey="true" nullable="false"/>
               </column>
               <column name="name" type="varchar(100)">
                   <constraints nullable="false"/>
               </column>
               <column name="position" type="varchar(100)">
                   <constraints nullable="true"/>
               </column>
               <column name="salary" type="decimal(10,2)">
                   <constraints nullable="true"/>
               </column>
           </createTable>
       </changeSet>

   </databaseChangeLog>
   ```

   Replace `"yourusername"` with your actual username or identifier.

3. **Configure Liquibase in Spring Boot**

   Update your `application.properties` to include Liquibase configuration:

   ```properties
   spring.datasource.url=jdbc:postgresql://<your-postgres-server>.postgres.database.azure.com:5432/<your-database>
   spring.datasource.username=<your-managed-identity-client-id>
   spring.datasource.password=
   spring.liquibase.change-log=classpath:db-changelog.xml
   spring.liquibase.enabled=true
   ```

   Ensure that the `spring.datasource.username` is set to your managed identity's client ID.

4. **Run Liquibase**

   When you start your Spring Boot application, Liquibase will automatically run the changelog and apply the changes to your PostgreSQL database.

### Example Java Configuration (for Managed Identity)

To authenticate with Managed Identity in Spring Boot, update your configuration as follows:

```java
import com.azure.identity.DefaultAzureCredentialBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;

@Configuration
public class DataSourceConfig {

    @Bean
    public DataSource dataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("org.postgresql.Driver");
        dataSource.setUrl("jdbc:postgresql://<your-postgres-server>.postgres.database.azure.com:5432/<your-database>");

        // Use DefaultAzureCredentialBuilder to authenticate with Managed Identity
        DefaultAzureCredentialBuilder builder = new DefaultAzureCredentialBuilder();
        String token = builder.build().getToken("https://database.windows.net/").block().getToken();

        dataSource.setUsername("<your-managed-identity-client-id>");
        dataSource.setPassword(token);  // Token-based authentication

        return dataSource;
    }
}
```

**Note:**
- Replace `<your-postgres-server>`, `<your-database>`, and `<your-managed-identity-client-id>` with the actual values.
- Ensure that your application is running in an environment where it has access to Azure Managed Identity, such as Azure App Services or Azure Virtual Machines.

### Summary

The provided Liquibase changelog XML creates a schema and an `employee` table in PostgreSQL. You integrate this with a Spring Boot application that uses Azure Managed Identity for authentication. This setup ensures that your database schema is version-controlled and managed seamlessly through Liquibase.