Combining Karibu-DSL with Spring Boot provides a streamlined way to build Vaadin applications using Kotlin. Karibu-DSL offers a Kotlin-idiomatic approach for Vaadin, while Spring Boot handles the backend logic and integration.

Here's how to set up a Vaadin application using Karibu-DSL with Spring Boot:

### 1. Set Up Your Spring Boot Project with Kotlin and Karibu-DSL

First, ensure you have a Spring Boot project set up with Kotlin and the necessary dependencies.

#### Gradle Configuration (`build.gradle.kts`):

```kotlin
plugins {
    id("org.springframework.boot") version "3.2.0"
    id("io.spring.dependency-management") version "1.1.0"
    kotlin("jvm") version "1.9.0"
    kotlin("plugin.spring") version "1.9.0"
}

repositories {
    mavenCentral()
}

dependencies {
    implementation("org.springframework.boot:spring-boot-starter")
    implementation("com.vaadin:vaadin-core:23.0.0") // Use the latest version
    implementation("com.github.mvysny.karibu-dsl:karibu-dsl:1.4.0") // Use the latest version
    implementation("org.jetbrains.kotlin:kotlin-reflect")
    implementation("org.jetbrains.kotlin:kotlin-stdlib-jdk8")
    testImplementation("org.springframework.boot:spring-boot-starter-test")
}
```

### 2. Create a Kotlin Data Class for `Student`

Define the data class to represent the student entity.

```kotlin
package com.example.application.entity

data class Student(
    var firstName: String? = null,
    var lastName: String? = null,
    var email: String? = null,
    var phoneNumber: String? = null
)
```

### 3. Create the Vaadin Form View Using Karibu-DSL

Create the `StudentFormView.kt` file using Karibu-DSL for the UI.

```kotlin
package com.example.application.views

import com.example.application.entity.Student
import com.github.mvysny.karibudsl.v10.*
import com.vaadin.flow.component.button.Button
import com.vaadin.flow.component.notification.Notification
import com.vaadin.flow.router.Route
import com.vaadin.flow.data.binder.Binder
import com.vaadin.flow.component.orderedlayout.VerticalLayout
import org.springframework.stereotype.Component

@Route("student-form")
@Component
class StudentFormView : VerticalLayout() {

    private val binder = Binder(Student::class.java)

    init {
        // Create the form layout using Karibu-DSL
        dslForm {
            // Create form fields
            val firstNameField by textField("First Name")
            val lastNameField by textField("Last Name")
            val emailField by textField("Email")
            val phoneNumberField by textField("Phone Number")

            // Create the submit button
            val submitButton = Button("Register").apply {
                addClickListener {
                    submitForm()
                }
            }

            // Add fields and button to the form
            add(firstNameField, lastNameField, emailField, phoneNumberField, submitButton)

            // Bind fields to the student entity
            binder.bindInstanceFields(this)
        }
    }

    private fun submitForm() {
        val student = Student()
        if (binder.writeBeanIfValid(student)) {
            // Here you would typically save the student entity to the database
            Notification.show("Student registered: ${student.firstName} ${student.lastName}")
        } else {
            Notification.show("Please fill out all fields correctly.")
        }
    }
}
```

### 4. Configure the Spring Boot Application

Ensure you have a Spring Boot application class to run the application.

```kotlin
package com.example.application

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class Application

fun main(args: Array<String>) {
    runApplication<Application>(*args)
}
```

### 5. Create a `VaadinServlet` Configuration (Optional)

In case you need to configure Vaadin servlet explicitly (usually optional with Spring Boot):

```kotlin
package com.example.application.config

import com.vaadin.flow.server.VaadinServlet
import javax.servlet.annotation.WebServlet
import org.springframework.context.annotation.Configuration

@Configuration
class VaadinConfig {

    @WebServlet(urlPatterns = ["/*"], name = "VaadinServlet", asyncSupported = true)
    class VaadinServletConfig : VaadinServlet()
}
```

### Summary

This setup demonstrates how to use Karibu-DSL with Spring Boot to create a Vaadin application in Kotlin. The `StudentFormView` class utilizes Karibu-DSL for a more Kotlin-friendly UI creation, and Spring Boot handles the application configuration and running. The Karibu-DSL library provides a more idiomatic Kotlin API for Vaadin, making your code cleaner and easier to maintain.

Feel free to expand upon this basic setup by adding services, repositories, and additional views as needed for your application.

### Reference

[Without_spring_boot](https://github.com/mvysny/vaadin-boot)
[karibu-dsl](https://github.com/mvysny/karibu-dsl?tab=readme-ov-file)