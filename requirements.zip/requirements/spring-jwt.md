Certainly! To create a JWT using a symmetric key and validate it in a Spring Boot Security application, you'll need to:

1. Generate and sign the JWT using a symmetric key.
2. Configure Spring Security to use the symmetric key to validate the JWT.

Here’s a step-by-step guide with example code:

### 1. Set Up Dependencies

Make sure you have the following dependencies in your `pom.xml` if you are using Maven:

```xml
<dependencies>
    <!-- Spring Boot Starter Web -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>

    <!-- Spring Boot Starter Security -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-security</artifactId>
    </dependency>

    <!-- JWT Library -->
    <dependency>
        <groupId>io.jsonwebtoken</groupId>
        <artifactId>jjwt</artifactId>
        <version>0.11.5</version> <!-- Use the latest version -->
    </dependency>

    <!-- Spring Boot Starter Test -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-test</artifactId>
        <scope>test</scope>
    </dependency>
</dependencies>
```

### 2. JWT Utility Class

Create a utility class for generating and parsing JWT tokens using a symmetric key.

```java
package com.example.demo.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class JwtUtil {

    @Value("${jwt.secret}")
    private String secretKey;

    @Value("${jwt.expiration}")
    private long expirationMs;

    public String generateToken(String username) {
        return Jwts.builder()
                .setSubject(username)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + expirationMs))
                .signWith(SignatureAlgorithm.HS256, secretKey)
                .compact();
    }

    public Claims extractClaims(String token) {
        return Jwts.parser()
                .setSigningKey(secretKey)
                .parseClaimsJws(token)
                .getBody();
    }

    public String extractUsername(String token) {
        return extractClaims(token).getSubject();
    }

    public boolean isTokenExpired(String token) {
        return extractClaims(token).getExpiration().before(new Date());
    }

    public boolean validateToken(String token, String username) {
        return (username.equals(extractUsername(token)) && !isTokenExpired(token));
    }
}
```

### 3. Spring Security Configuration

Configure Spring Security to use the JWT for authentication.

```java
package com.example.demo.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.builders.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    private JwtFilter jwtFilter;

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.csrf().disable()
                .authorizeRequests()
                .antMatchers("/authenticate").permitAll()
                .anyRequest().
```
---
Certainly! To create a Java client program that generates and manages JWTs using a symmetric key, you need to follow these steps:

1. **Include Dependencies**: Ensure you have the necessary library for JWT handling.
2. **Create JWT Utility**: Implement functionality to generate and parse JWT tokens.
3. **Create Client Program**: Use the utility to generate a JWT and print it out.

### 1. Include Dependencies

Make sure you include the necessary dependency in your `pom.xml` (if using Maven):

```xml
<dependencies>
    <!-- JWT Library -->
    <dependency>
        <groupId>io.jsonwebtoken</groupId>
        <artifactId>jjwt</artifactId>
        <version>0.11.5</version> <!-- Use the latest version -->
    </dependency>
</dependencies>
```

### 2. Create JWT Utility Class

This class will handle the creation and parsing of JWT tokens using a symmetric key.

```java
package com.example.jwtclient;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import java.util.Date;

public class JwtUtil {

    private final String secretKey = "mySecretKey"; // Symmetric key for signing JWT
    private final long expirationMs = 3600000; // 1 hour

    public String generateToken(String username) {
        return Jwts.builder()
                .setSubject(username)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + expirationMs))
                .signWith(SignatureAlgorithm.HS256, secretKey)
                .compact();
    }

    public Claims extractClaims(String token) {
        return Jwts.parser()
                .setSigningKey(secretKey)
                .parseClaimsJws(token)
                .getBody();
    }

    public String extractUsername(String token) {
        return extractClaims(token).getSubject();
    }

    public boolean isTokenExpired(String token) {
        return extractClaims(token).getExpiration().before(new Date());
    }

    public boolean validateToken(String token, String username) {
        return (username.equals(extractUsername(token)) && !isTokenExpired(token));
    }
}
```

### 3. Create JWT Client Program

This program will use the `JwtUtil` class to generate a JWT and print it.

```java
package com.example.jwtclient;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import java.util.Date;

public class JwtClient {

    private static final String SECRET_KEY = "mySecretKey"; // Symmetric key for signing JWT
    private static final long EXPIRATION_MS = 3600000; // 1 hour

    public static void main(String[] args) {
        JwtUtil jwtUtil = new JwtUtil();

        // Generate a token
        String username = "user123";
        String token = jwtUtil.generateToken(username);
        System.out.println("Generated Token: " + token);

        // Parse and validate the token
        Claims claims = jwtUtil.extractClaims(token);
        String extractedUsername = jwtUtil.extractUsername(token);
        boolean isExpired = jwtUtil.isTokenExpired(token);
        boolean isValid = jwtUtil.validateToken(token, username);

        // Output token details
        System.out.println("Extracted Username: " + extractedUsername);
        System.out.println("Is Token Expired: " + isExpired);
        System.out.println("Is Token Valid: " + isValid);
    }
}
```

### Explanation

1. **`JwtUtil` Class**:
    - **`generateToken`**: Creates a JWT token signed with a symmetric key and includes the username as the subject.
    - **`extractClaims`**: Parses the token to extract claims.
    - **`extractUsername`**: Extracts the username from the token.
    - **`isTokenExpired`**: Checks if the token has expired.
    - **`validateToken`**: Validates the token against the username and expiration.

2. **`JwtClient` Program**:
    - **Generates a JWT**: Calls `generateToken` with a sample username.
    - **Parses and Validates**: Uses the JWT utility methods to extract information and validate the token.
    - **Prints Results**: Outputs the token and its validation results.

### Running the Program

To run the `JwtClient` program, make sure you have the necessary dependencies and execute the `main` method. This will generate a JWT, print it, and show the results of validation checks.

### Reference
[JWT_Springboot_3](https://medium.com/@tericcabrel/implement-jwt-authentication-in-a-spring-boot-3-application-5839e4fd8fac)
[jwt_git](https://github.com/ali-bouali/spring-boot-3-jwt-security)
[Auth0_example1](https://auth0.com/docs/quickstart/backend/java-spring-security5/01-authorization)
[Auth0_example2](https://auth0.com/docs/quickstart/webapp/java-spring-boot/01-login)
[Auth0_example3](https://www.baeldung.com/spring-security-auth0)
[Auth0-example4](https://auth0.com/docs/quickstart/backend/java-spring-security5/interactive)
[Okta](https://github.com/okta/okta-spring-boot/)


