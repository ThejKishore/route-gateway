# Create user-managed identity for Storage Account
To create a user-managed identity in Azure and assign it read-write access to Azure Blob Storage using Terraform, you need to follow these steps:

1. **Create a User-Managed Identity**
2. **Create a Storage Account**
3. **Assign Role-Based Access Control (RBAC) permissions to the User-Managed Identity**

Here's an example Terraform code to achieve this:

### Terraform Code

```hcl
provider "azurerm" {
  features {}
}

# Variables
variable "resource_group_name" {
  default = "my-resource-group"
}

variable "storage_account_name" {
  default = "mystorageaccount123"  # Must be globally unique
}

variable "location" {
  default = "East US"
}

# Create Resource Group
resource "azurerm_resource_group" "example" {
  name     = var.resource_group_name
  location = var.location
}

# Create User-Managed Identity
resource "azurerm_user_assigned_identity" "example" {
  name                = "my-identity"
  resource_group_name = azurerm_resource_group.example.name
  location            = azurerm_resource_group.example.location
}

# Create Storage Account
resource "azurerm_storage_account" "example" {
  name                     = var.storage_account_name
  resource_group_name      = azurerm_resource_group.example.name
  location                 = azurerm_resource_group.example.location
  account_tier             = "Standard"
  account_replication_type = "LRS"

  # Required for authentication with Managed Identity
  enable_https_traffic_only = true
}

# Assign RBAC Role to User-Managed Identity
resource "azurerm_role_assignment" "storage_blob_data_contributor" {
  principal_id   = azurerm_user_assigned_identity.example.principal_id
  role_definition_name = "Storage Blob Data Contributor"  # Role with read/write permissions for Blob Storage
  scope          = azurerm_storage_account.example.id
}

output "identity_client_id" {
  value = azurerm_user_assigned_identity.example.client_id
}

output "identity_id" {
  value = azurerm_user_assigned_identity.example.id
}
```

### Explanation

1. **Provider Block:** Specifies the `azurerm` provider for Terraform.

2. **Variables:** Define necessary variables such as resource group name, storage account name, and location.

3. **Resource Group:** Creates an Azure Resource Group where other resources will be deployed.

4. **User-Managed Identity:** Creates a user-assigned managed identity.

5. **Storage Account:** Creates an Azure Storage Account where blobs will be stored.

6. **Role Assignment:** Assigns the `Storage Blob Data Contributor` role to the managed identity, which grants it read and write access to the Blob Storage.

7. **Outputs:** Provide the client ID and ID of the managed identity as outputs.

### Applying the Configuration

To apply this Terraform configuration:

1. Save the code into a file, e.g., `main.tf`.
2. Initialize Terraform:
   ```bash
   terraform init
   ```
3. Plan the deployment:
   ```bash
   terraform plan
   ```
4. Apply the configuration:
   ```bash
   terraform apply
   ```

Make sure to replace the placeholders and variable values as needed to fit your environment and ensure that the storage account name is globally unique.