# Service_discovery

Certainly! Here’s how you can handle service discovery in Azure Container Apps using Java, both with and without Dapr.

### 1. **Service Discovery in Azure Container Apps with Dapr Using Java**

#### **Using Dapr for Service Discovery**

**1. Deploy Azure Container Apps with Dapr Enabled:**

When you deploy Azure Container Apps with Dapr, ensure that Dapr is enabled. This involves setting up your container apps with the necessary Dapr configurations. Here’s how you can do it using Terraform:

```hcl
resource "azurerm_container_app" "example" {
  name                = "example-app"
  resource_group_name = azurerm_resource_group.example.name
  location            = azurerm_resource_group.example.location
  environment_name    = azurerm_container_app_environment.example.name

  configuration {
    dapr {
      enabled = true
    }
  }

  container {
    name   = "example-container"
    image  = "example/image:latest"
    cpu    = "0.5"
    memory = "1Gi"

    dapr {
      enabled = true
      app_id   = "example-app"
    }
  }
}
```

**2. Use Dapr Service Invocation API in Java:**

To communicate with other services using Dapr in a Java application, you can use Dapr's Service Invocation API. Here’s an example using Java’s `HttpClient` to make requests:

```java
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class DaprServiceClient {
    private static final String DAPR_HTTP_PORT = "3500"; // Default Dapr HTTP port

    public static void main(String[] args) {
        String appId = "other-app";
        String method = "api-endpoint";
        String daprUrl = String.format("http://localhost:%s/v1.0/invoke/%s/method/%s", DAPR_HTTP_PORT, appId, method);

        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(daprUrl))
                .GET()
                .build();

        client.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenAccept(response -> {
                    System.out.println("Response: " + response.body());
                })
                .join();
    }
}
```

In this example:
- `appId` is the ID of the service you want to communicate with.
- `method` is the endpoint within that service.

**3. Implement Service Discovery with Dapr:**

- Ensure your service is registered with Dapr using the `app_id`.
- Other services can discover and communicate with it using Dapr's service invocation API.

### 2. **Service Discovery in Azure Container Apps Without Dapr Using Java**

Without Dapr, you will need to use alternative Azure services for service discovery and routing.

#### **Using Azure Application Gateway**

1. **Deploy Azure Application Gateway:**

   Configure the Application Gateway to route traffic to your container apps. You may need to configure backend pools and routing rules using the Azure Portal or Terraform.

2. **Access Services via Application Gateway:**

   Use the Application Gateway’s URL to access your services. You can configure the gateway to route requests to specific container apps based on the URL path.

#### **Using Azure Service Bus**

1. **Send and Receive Messages Using Azure Service Bus:**

   If you’re using Azure Service Bus, you can send and receive messages between services. Here’s how you can use Azure Service Bus with Java:

   **Dependencies:**

   Add the following dependencies to your `pom.xml`:

   ```xml
   <dependency>
       <groupId>com.microsoft.azure</groupId>
       <artifactId>azure-servicebus</artifactId>
       <version>3.6.0</version>
   </dependency>
   ```

   **Send a Message:**

   ```java
   import com.microsoft.azure.servicebus.QueueClient;
   import com.microsoft.azure.servicebus.ServiceBusException;
   import com.microsoft.azure.servicebus.Message;
   import com.microsoft.azure.servicebus.primitives.ConnectionStringBuilder;

   public class ServiceBusSender {
       private static final String CONNECTION_STRING = "<your-service-bus-connection-string>";
       private static final String QUEUE_NAME = "<your-queue-name>";

       public static void main(String[] args) throws ServiceBusException, InterruptedException {
           QueueClient queueClient = new QueueClient(new ConnectionStringBuilder(CONNECTION_STRING, QUEUE_NAME), com.microsoft.azure.servicebus.ReceiveMode.PEEKLOCK);

           Message message = new Message("Hello, World!");
           queueClient.send(message);

           System.out.println("Message sent.");
           queueClient.close();
       }
   }
   ```

   **Receive a Message:**

   ```java
   import com.microsoft.azure.servicebus.QueueClient;
   import com.microsoft.azure.servicebus.ServiceBusException;
   import com.microsoft.azure.servicebus.Message;
   import com.microsoft.azure.servicebus.primitives.ConnectionStringBuilder;

   public class ServiceBusReceiver {
       private static final String CONNECTION_STRING = "<your-service-bus-connection-string>";
       private static final String QUEUE_NAME = "<your-queue-name>";

       public static void main(String[] args) throws ServiceBusException, InterruptedException {
           QueueClient queueClient = new QueueClient(new ConnectionStringBuilder(CONNECTION_STRING, QUEUE_NAME), com.microsoft.azure.servicebus.ReceiveMode.PEEKLOCK);

           Message message = queueClient.receive();
           if (message != null) {
               System.out.println("Received message: " + new String(message.getBody()));
               queueClient.complete(message.getLockToken());
           }

           queueClient.close();
       }
   }
   ```

#### **Using Azure API Management**

1. **Expose Services via APIs:**

   Use Azure API Management to create APIs that map to your container apps. Define API operations and routes in Azure API Management to direct traffic to the appropriate container apps.

2. **Access Services through API Management:**

   Use the API Management endpoints in your Java application to access your services. For example:

   ```java
   import java.net.URI;
   import java.net.http.HttpClient;
   import java.net.http.HttpRequest;
   import java.net.http.HttpResponse;

   public class ApiManagementClient {
       public static void main(String[] args) {
           String apiUrl = "https://your-api-management-instance.azure-api.net/api-endpoint";

           HttpClient client = HttpClient.newHttpClient();
           HttpRequest request = HttpRequest.newBuilder()
                   .uri(URI.create(apiUrl))
                   .GET()
                   .header("Ocp-Apim-Subscription-Key", "<your-subscription-key>")
                   .build();

           client.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                   .thenAccept(response -> {
                       System.out.println("Response: " + response.body());
                   })
                   .join();
       }
   }
   ```

    - Replace `<your-subscription-key>` with the key for your API in API Management.

### Summary

- **With Dapr**: Use Dapr's built-in service invocation API for service discovery and communication in Java. Services can be addressed using their `app_id`, and communication is handled through Dapr sidecars.

- **Without Dapr**: Use Azure-native services like Application Gateway, Service Bus, or API Management for service discovery and communication. Java code will involve HTTP requests, Service Bus SDKs, or API Management configurations to manage service interactions.

Both approaches depend on your architecture needs and the complexity of your service interactions. Dapr simplifies service discovery and communication, while Azure-native services offer robust alternatives.