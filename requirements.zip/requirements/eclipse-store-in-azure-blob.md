To create a Spring Data application that connects to Azure Blob Storage using EclipseStore, you'll need to configure your application with the appropriate settings and dependencies. Here’s a step-by-step guide to set this up, based on the provided documentation and example.

### 1. Add Dependencies

First, ensure you have the necessary dependencies in your `pom.xml` if you are using Maven, or in `build.gradle` if you are using Gradle. For Maven, include the following dependencies:

```xml
<dependencies>
    <!-- Spring Boot Starter for Data JPA -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-data-jpa</artifactId>
    </dependency>

    <!-- Spring Boot Starter for Web -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>

    <!-- EclipseStore for Spring Data -->
    <dependency>
        <groupId>software.xdev</groupId>
        <artifactId>spring-data-eclipse-store</artifactId>
        <version>2.0.0</version> <!-- Replace with the latest version -->
    </dependency>

    <!-- Azure Storage Blob -->
    <dependency>
        <groupId>com.azure</groupId>
        <artifactId>azure-storage-blob</artifactId>
        <version>12.15.0</version> <!-- Replace with the latest version -->
    </dependency>
</dependencies>
```

For Gradle, add these dependencies to your `build.gradle`:

```groovy
dependencies {
    implementation 'org.springframework.boot:spring-boot-starter-data-jpa'
    implementation 'org.springframework.boot:spring-boot-starter-web'
    implementation 'software.xdev:spring-data-eclipse-store:2.0.0' // Replace with the latest version
    implementation 'com.azure:azure-storage-blob:12.15.0' // Replace with the latest version
}
```

### 2. Configure Azure Blob Storage

You need to configure Azure Blob Storage as your storage target in EclipseStore. Create a configuration class similar to the `ComplexConfiguration` class from the demo.

Here's an example `AzureBlobConfiguration.java` class:

```java
package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.repository.config.EnableJpaRepositories;
import software.xdev.spring.data.eclipse.store.EclipseStoreConfiguration;
import software.xdev.spring.data.eclipse.store.blobstore.azure.AzureBlobStoreConfiguration;

@Configuration
@EnableJpaRepositories(basePackages = "com.example.demo.repository")
public class AzureBlobConfiguration {

    @Bean
    public EclipseStoreConfiguration eclipseStoreConfiguration() {
        return new EclipseStoreConfiguration()
                .addStorageTarget(new AzureBlobStoreConfiguration()
                        .withConnectionString("DefaultEndpointsProtocol=https;AccountName=your_account_name;AccountKey=your_account_key;EndpointSuffix=core.windows.net")
                        .withContainerName("your-container-name")
                );
    }
}
```

In this configuration:

- Replace `"DefaultEndpointsProtocol=https;AccountName=your_account_name;AccountKey=your_account_key;EndpointSuffix=core.windows.net"` with your actual Azure Blob Storage connection string.
- Replace `"your-container-name"` with the name of your blob container.

### 3. Define Your Entity

Create an entity that represents the data you want to store in Azure Blob Storage. For example:

```java
package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;

@Entity
public class BlobEntity {

    @Id
    private String id;

    @Lob
    private byte[] data;

    // Getters and setters
}
```

### 4. Create a Repository

Define a repository interface for your entity:

```java
package com.example.demo.repository;

import com.example.demo.model.BlobEntity;
import org.springframework.data.repository.CrudRepository;

public interface BlobEntityRepository extends CrudRepository<BlobEntity, String> {
}
```

### 5. Application Properties

Ensure you have the necessary properties in your `application.properties` or `application.yml` file:

```properties
# Azure Blob Storage connection string
spring.data.eclipse.store.azure.connection-string=DefaultEndpointsProtocol=https;AccountName=your_account_name;AccountKey=your_account_key;EndpointSuffix=core.windows.net
spring.data.eclipse.store.azure.container-name=your-container-name
```

### 6. Running the Application

Finally, make sure you have a main application class to run your Spring Boot application:

```java
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }
}
```

### Summary

This setup will allow your Spring Data application to interact with Azure Blob Storage using EclipseStore. Make sure to replace placeholders with your actual Azure Blob Storage credentials and details. Adjust versions of dependencies as necessary to keep up with the latest releases.

### reference

[Complex Configuration](https://github.com/xdev-software/spring-data-eclipse-store/blob/develop/spring-data-eclipse-store-demo/src/main/java/software/xdev/spring/data/eclipse/store/demo/complex/ComplexConfiguration.java)
[Azure Dependency](https://docs.eclipsestore.io/manual/storage/storage-targets/blob-stores/azure-storage.html)