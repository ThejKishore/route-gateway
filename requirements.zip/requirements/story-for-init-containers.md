# Secret and App Configuration Init Container...


# Secrets and Configurations: A Spring Developer's Quest

In the tech capital of a bustling city, Sam, a talented Spring Java developer, faced a new challenge. Their team needed to deploy a critical application that required integrating secrets from Azure Key Vault and configurations from Azure App Configuration. The plan was to use Kubernetes init containers to handle these tasks before the main application started. Sam’s expertise in Spring Java would be crucial for this endeavor.

## Part 1: The Key Vault Init Container

Sam started by creating a Docker image for an init container that would fetch secrets from Azure Key Vault and set them as environment variables.

### Preparation for KeyVault

1. **Spring Boot Application for Fetching Secrets**

   First, Sam created a Spring Boot application specifically for fetching secrets. This app used the Azure SDK for Java to connect to Azure Key Vault.

   **`pom.xml`** (Dependencies for the Spring Boot application)

```xml
<dependencies>
   <dependency>
       <groupId>com.microsoft.azure</groupId>
       <artifactId>azure-security-keyvault-secrets</artifactId>
       <version>4.3.0</version>
   </dependency>
   <dependency>
       <groupId>org.springframework.boot</groupId>
       <artifactId>spring-boot-starter</artifactId>
   </dependency>
</dependencies>
```

**`KeyVaultInitApplication.java`** (Spring Boot application to fetch secrets)

```java
package com.example.keyvaultinit;

import com.azure.identity.DefaultAzureCredentialBuilder;
import com.azure.security.keyvault.secrets.SecretClient;
import com.azure.security.keyvault.secrets.SecretClientBuilder;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;

@SpringBootApplication
public class KeyVaultInitApplication implements CommandLineRunner {

   private final Environment environment;

   public KeyVaultInitApplication(Environment environment) {
       this.environment = environment;
   }

   public static void main(String[] args) {
       SpringApplication.run(KeyVaultInitApplication.class, args);
   }

   @Override
   public void run(String... args) throws Exception {
       String keyVaultUrl = environment.getProperty("KEY_VAULT_URL");
       SecretClient secretClient = new SecretClientBuilder()
           .vaultUrl(keyVaultUrl)
           .credential(new DefaultAzureCredentialBuilder().build())
           .buildClient();

       // Fetch and print secrets
       String databasePassword = secretClient.getSecret("DATABASE_PASSWORD").getValue();
       String apiKey = secretClient.getSecret("API_KEY").getValue();

       System.out.println("DATABASE_PASSWORD=" + databasePassword);
       System.out.println("API_KEY=" + apiKey);
   }
}
```

**Dockerfile** (Docker image for Key Vault init container)

```Docker
FROM openjdk:17-jdk-slim

COPY target/keyvault-init-0.0.1-SNAPSHOT.jar /app/keyvault-init.jar

ENTRYPOINT ["java", "-jar", "/app/keyvault-init.jar"]
```

   Sam built and pushed this Docker image to a container registry.

### Deployment Configuration for Key Vault 

Sam then configured the init container in the Kubernetes deployment YAML file.

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: my-app
spec:
  replicas: 1
  template:
    spec:
      initContainers:
      - name: keyvault-init
        image: myregistry/keyvault-init:latest
        env:
        - name: KEY_VAULT_URL
          value: "https://mykeyvault.vault.azure.net/"
        volumeMounts:
        - name: secrets-store
          mountPath: /mnt/secrets
      containers:
      - name: main-app
        image: myregistry/main-app:latest
        volumeMounts:
        - name: secrets-store
          mountPath: /mnt/secrets
      volumes:
      - name: secrets-store
        emptyDir: {}
```

## Part 2: The Azure App Configuration Init Container

With the Key Vault init container ready, Sam turned their attention to creating an init container for fetching configurations from Azure App Configuration.

### Preparation

2. **Spring Boot Application for Fetching Configurations**

   Similar to the Key Vault init container, Sam created a Spring Boot application for fetching configurations from Azure App Configuration.

**`pom.xml`** (Dependencies for the Spring Boot application)

```xml
<dependencies>
   <dependency>
       <groupId>com.azure</groupId>
       <artifactId>azure-appconfiguration</artifactId>
       <version>1.0.0</version>
   </dependency>
   <dependency>
       <groupId>org.springframework.boot</groupId>
       <artifactId>spring-boot-starter</artifactId>
   </dependency>
</dependencies>
```

**`AppConfigInitApplication.java`** (Spring Boot application to fetch configurations)

```java
package com.example.appconfiginit;

import com.azure.data.appconfiguration.ConfigurationClient;
import com.azure.data.appconfiguration.ConfigurationClientBuilder;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;

import java.io.FileWriter;
import java.io.IOException;

@SpringBootApplication
public class AppConfigInitApplication implements CommandLineRunner {

   private final Environment environment;

   public AppConfigInitApplication(Environment environment) {
       this.environment = environment;
   }

   public static void main(String[] args) {
       SpringApplication.run(AppConfigInitApplication.class, args);
   }

   @Override
   public void run(String... args) throws Exception {
       String connectionString = environment.getProperty("APP_CONFIG_CONNECTION_STRING");
       ConfigurationClient client = new ConfigurationClientBuilder()
           .connectionString(connectionString)
           .buildClient();

       // Fetch configurations
       StringBuilder configs = new StringBuilder();
       client.listConfigurationSettings().forEach(setting -> {
           configs.append(setting.getKey()).append("=").append(setting.getValue()).append("\n");
       });

       // Write configs to a file
       try (FileWriter writer = new FileWriter("/mnt/configs/configs.txt")) {
           writer.write(configs.toString());
       }

       System.out.println("Configurations fetched and written to /mnt/configs/configs.txt.");
   }
}
```

**Dockerfile** (Docker image for App Configuration init container)

```Docker
FROM openjdk:17-jdk-slim

COPY target/appconfig-init-0.0.1-SNAPSHOT.jar /app/appconfig-init.jar

ENTRYPOINT ["java", "-jar", "/app/appconfig-init.jar"]
```

   Sam built and pushed this Docker image to a container registry as well.

### Deployment Configuration

Sam updated the Kubernetes deployment YAML to include this second init container.

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: my-app
spec:
  replicas: 1
  template:
    spec:
      initContainers:
      - name: keyvault-init
        image: myregistry/keyvault-init:latest
        env:
        - name: KEY_VAULT_URL
          value: "https://mykeyvault.vault.azure.net/"
        volumeMounts:
        - name: secrets-store
          mountPath: /mnt/secrets
      - name: appconfig-init
        image: myregistry/appconfig-init:latest
        env:
        - name: APP_CONFIG_CONNECTION_STRING
          value: "Endpoint=https://myappconfig.azconfig.io;Id=...;Secret=..."
        volumeMounts:
        - name: configs-store
          mountPath: /mnt/configs
      containers:
      - name: main-app
        image: myregistry/main-app:latest
        volumeMounts:
        - name: secrets-store
          mountPath: /mnt/secrets
        - name: configs-store
          mountPath: /mnt/configs
      volumes:
      - name: secrets-store
        emptyDir: {}
      - name: configs-store
        emptyDir: {}
```

## Epilogue

Sam watched with satisfaction as the Kubernetes deployment took shape. The init containers sprang into action—fetching secrets from Azure Key Vault and configurations from Azure App Configuration, preparing everything for the main application container. The approach ensured that the application was securely and efficiently configured, showcasing Sam's prowess in leveraging Spring Boot and Kubernetes for a seamless deployment process.

---