# SPA_with_custom_domain

To build and serve a Single Page Application (SPA) from Azure Blob Storage, you'll need to follow these steps:

### 1. **Prepare Your SPA**

1. **Build Your SPA:**
   Ensure that your SPA is ready for deployment. This usually involves running a build command provided by your framework or library. For example, in React, you might use:
   ```bash
   npm run build
   ```
   This generates a `build` directory with your static assets (HTML, CSS, JS files).

### 2. **Create an Azure Storage Account**

1. **Log in to Azure Portal:**
   Go to the [Azure Portal](https://portal.azure.com/).

2. **Create a Storage Account:**
    - Navigate to **Storage Accounts** and click **+ Create**.
    - Fill out the required details (Resource Group, Storage Account Name, Region, etc.).
    - Choose the **StorageV2** (General-purpose v2) for the account type.
    - Click **Review + Create**, then **Create**.

### 3. **Configure Azure Blob Storage**

1. **Navigate to Your Storage Account:**
    - Once created, go to the **Storage Account** dashboard.

2. **Create a Container:**
    - Go to **Containers** under **Data storage**.
    - Click **+ Container**.
    - Set the **Name** and choose **Public access level** as `Blob (anonymous read access for blobs only)`.
    - Click **Create**.

3. **Upload Your SPA Assets:**
    - Go to your newly created container.
    - Click **Upload** and select the contents of your `build` directory from your local machine.
    - Alternatively, you can use Azure CLI or AzCopy for large-scale uploads.

### 4. **Configure Static Website Hosting**

1. **Enable Static Website Hosting:**
    - In the Storage Account dashboard, go to **Static website** under **Settings**.
    - Click **Enabled**.
    - Set the **Index document name** to `index.html` (or whatever your main HTML file is named).
    - Set the **Error document path** if applicable (e.g., `404.html`).
    - Click **Save**.

2. **Note the Endpoint URL:**
    - After enabling static website hosting, you’ll see a **Primary web endpoint** URL. This is the URL where your SPA will be accessible.

### 5. **Test Your Application**

- Navigate to the **Primary web endpoint** URL provided in the previous step to ensure your SPA is loading correctly.

### 6. **Optional: Custom Domain and HTTPS**

1. **Custom Domain:**
    - If you want to use a custom domain, you’ll need to set up Azure CDN or Azure Front Door in front of your storage account.
    - Follow Azure documentation for [configuring a custom domain](https://docs.microsoft.com/azure/storage/blobs/storage-custom-domain-name) with Azure Blob Storage.

2. **HTTPS:**
    - By default, Azure Blob Storage static websites are served over HTTPS. Ensure your custom domain setup includes HTTPS configuration if using a custom domain.

### 7. **Set Up Caching and Security**

- **Caching:**
    - Use Azure CDN for caching and optimizing performance.
- **Security:**
    - Implement any necessary security measures such as Access Control Lists (ACLs) or using Azure Front Door for additional security features.

By following these steps, you can build, deploy, and serve a single-page application directly from Azure Blob Storage. This setup is cost-effective and scalable for static web applications.

Mapping a custom domain to an Azure Blob Storage endpoint using Terraform involves several steps. You'll need to configure your Azure Blob Storage to serve static content, set up Azure CDN for custom domain management, and configure DNS settings for your custom domain. Here's how you can achieve this:

### Prerequisites

1. **Terraform** installed on your local machine.
2. **Azure CLI** or Azure credentials configured for Terraform.
3. **Custom Domain** purchased and accessible for DNS configuration.

### Steps to Map a Custom Domain to Azure Blob Storage Using Terraform

#### 1. **Set Up Your Terraform Configuration**

Create a Terraform configuration file (`main.tf`) to define the necessary Azure resources.

```hcl
provider "azurerm" {
  features {}
}

# Resource Group
resource "azurerm_resource_group" "example" {
  name     = "example-resources"
  location = "West Europe"
}

# Storage Account
resource "azurerm_storage_account" "example" {
  name                     = "examplestoracc"  # must be globally unique
  resource_group_name      = azurerm_resource_group.example.name
  location                 = azurerm_resource_group.example.location
  account_tier             = "Standard"
  account_replication_type = "LRS"
  enable_https_traffic_only = true
}

# Static Website Configuration
resource "azurerm_storage_container" "static_website" {
  name                  = "$web"
  storage_account_name  = azurerm_storage_account.example.name
  container_access_type = "container"
}

resource "azurerm_storage_account_static_website" "static_website" {
  storage_account_id = azurerm_storage_account.example.id
  index_document     = "index.html"
  error_document_404 = "404.html"
}

# CDN Profile
resource "azurerm_cdn_profile" "example" {
  name                = "example-cdn-profile"
  resource_group_name = azurerm_resource_group.example.name
  location            = "Global"
  sku                 = "Standard_Microsoft"
}

# CDN Endpoint
resource "azurerm_cdn_endpoint" "example" {
  name                = "example-cdn-endpoint"
  resource_group_name = azurerm_resource_group.example.name
  profile_name        = azurerm_cdn_profile.example.name
  is_https_enabled    = true
  origin_host_header  = azurerm_storage_account.example.primary_web_endpoint
  origin_path         = "/"
  origin {
    name      = "example-storage-origin"
    host_name = "${azurerm_storage_account.example.primary_web_endpoint}"
  }
}

# CDN Custom Domain
resource "azurerm_cdn_custom_domain" "example" {
  name                = "example-custom-domain"
  resource_group_name = azurerm_resource_group.example.name
  profile_name        = azurerm_cdn_profile.example.name
  endpoint_name       = azurerm_cdn_endpoint.example.name
  host_name           = "your-custom-domain.com"
}

# DNS Zone (if needed)
resource "azurerm_dns_zone" "example" {
  name                = "your-custom-domain.com"
  resource_group_name = azurerm_resource_group.example.name
}

# DNS A Record for CDN Endpoint
resource "azurerm_dns_a_record" "example" {
  name                = "@"
  zone_name           = azurerm_dns_zone.example.name
  resource_group_name = azurerm_resource_group.example.name
  ttl                 = 3600
  records             = [azurerm_cdn_endpoint.example.host_name]
}
```

#### 2. **Deploy the Terraform Configuration**

1. **Initialize Terraform:**
   ```bash
   terraform init
   ```

2. **Plan the Deployment:**
   ```bash
   terraform plan
   ```

3. **Apply the Configuration:**
   ```bash
   terraform apply
   ```

   Confirm the apply action when prompted.

### Explanation

- **`azurerm_storage_account`**: Defines the Azure Storage Account where your static website will be hosted.
- **`azurerm_storage_container`**: Creates a container for your static website files.
- **`azurerm_storage_account_static_website`**: Configures the storage account to serve static content.
- **`azurerm_cdn_profile` and `azurerm_cdn_endpoint`**: Sets up Azure CDN to serve content from the storage account and manage custom domains.
- **`azurerm_cdn_custom_domain`**: Configures the custom domain with the CDN endpoint.
- **`azurerm_dns_zone` and `azurerm_dns_a_record`**: (Optional) Create a DNS zone and A record for the custom domain if managing DNS within Azure.

### Post-Deployment Steps

1. **DNS Configuration:**
    - Ensure that your custom domain DNS settings point to the CDN endpoint. This is often done via the DNS provider where your domain is registered.

2. **Verify:**
    - Check that the custom domain correctly resolves to your SPA hosted in Azure Blob Storage.

By using Terraform for infrastructure as code, you ensure that your deployment is reproducible and maintainable.

## serve multiple Single Page Applications (SPAs) from the same Azure Storage Account using different paths and the same custom domain

you can serve multiple Single Page Applications (SPAs) from the same Azure Storage Account using different paths and the same custom domain, but it requires some configuration. Here’s how you can achieve this:

### Approach Overview

1. **Use Azure Storage Containers**: Store each SPA in a separate container within the same Azure Storage Account.
2. **Configure Azure CDN**: Use Azure CDN to manage routing and serve content from different containers based on the URL path.
3. **Set Up Custom Domain**: Map the custom domain to the Azure CDN endpoint.

### Step-by-Step Guide

#### 1. **Set Up Azure Storage**

1. **Create a Storage Account**:
   If you don’t already have one, create a Storage Account in Azure.

2. **Create Containers for Each SPA**:
   In your Storage Account, create separate containers for each SPA. For example:
    - `spa1` for the first SPA
    - `spa2` for the second SPA

   Each container will hold the built files for its respective SPA.

3. **Upload SPA Files**:
   Upload the build files for each SPA into the corresponding container.

#### 2. **Set Up Azure CDN**

1. **Create a CDN Profile**:
   Create an Azure CDN Profile if you don’t have one.

   ```hcl
   resource "azurerm_cdn_profile" "example" {
     name                = "example-cdn-profile"
     resource_group_name = azurerm_resource_group.example.name
     location            = "Global"
     sku                 = "Standard_Microsoft"
   }
   ```

2. **Create CDN Endpoints for Each SPA**:
   Create separate CDN endpoints for each SPA. You can set up multiple origins for these endpoints, each pointing to a different container.

   ```hcl
   resource "azurerm_cdn_endpoint" "spa1" {
     name                = "spa1-cdn-endpoint"
     resource_group_name = azurerm_resource_group.example.name
     profile_name        = azurerm_cdn_profile.example.name
     is_https_enabled    = true
     origin_host_header  = "${azurerm_storage_account.example.primary_web_endpoint}/spa1"
     origin_path         = "/"
     
     origin {
       name      = "spa1-origin"
       host_name = "${azurerm_storage_account.example.primary_web_endpoint}/spa1"
     }
   }

   resource "azurerm_cdn_endpoint" "spa2" {
     name                = "spa2-cdn-endpoint"
     resource_group_name = azurerm_resource_group.example.name
     profile_name        = azurerm_cdn_profile.example.name
     is_https_enabled    = true
     origin_host_header  = "${azurerm_storage_account.example.primary_web_endpoint}/spa2"
     origin_path         = "/"
     
     origin {
       name      = "spa2-origin"
       host_name = "${azurerm_storage_account.example.primary_web_endpoint}/spa2"
     }
   }
   ```

3. **Configure Custom Domains for CDN Endpoints**:
   Configure custom domains for your CDN endpoints.

   ```hcl
   resource "azurerm_cdn_custom_domain" "spa1" {
     name                = "spa1-custom-domain"
     resource_group_name = azurerm_resource_group.example.name
     profile_name        = azurerm_cdn_profile.example.name
     endpoint_name       = azurerm_cdn_endpoint.spa1.name
     host_name           = "spa1.your-custom-domain.com"
   }

   resource "azurerm_cdn_custom_domain" "spa2" {
     name                = "spa2-custom-domain"
     resource_group_name = azurerm_resource_group.example.name
     profile_name        = azurerm_cdn_profile.example.name
     endpoint_name       = azurerm_cdn_endpoint.spa2.name
     host_name           = "spa2.your-custom-domain.com"
   }
   ```

   For each CDN endpoint, you will have a custom domain like `spa1.your-custom-domain.com` and `spa2.your-custom-domain.com`.

4. **Set Up DNS Records**:
   Update your DNS records to point to the CDN endpoints.

    - **DNS A Records or CNAME Records**: Point your custom domains to the CDN endpoint addresses provided by Azure.

   ```hcl
   resource "azurerm_dns_cname_record" "spa1" {
     name                = "spa1"
     zone_name           = "your-custom-domain.com"
     resource_group_name = azurerm_resource_group.example.name
     ttl                 = 3600
     record               = azurerm_cdn_endpoint.spa1.host_name
   }

   resource "azurerm_dns_cname_record" "spa2" {
     name                = "spa2"
     zone_name           = "your-custom-domain.com"
     resource_group_name = azurerm_resource_group.example.name
     ttl                 = 3600
     record               = azurerm_cdn_endpoint.spa2.host_name
   }
   ```

### Example Structure

- **Main Domain**: `your-custom-domain.com`
- **SPAs**:
    - **SPA 1**: Accessible at `spa1.your-custom-domain.com`
    - **SPA 2**: Accessible at `spa2.your-custom-domain.com`

### Notes

- **URL Path Routing**: If you want to serve multiple SPAs under different paths of the same domain (e.g., `your-custom-domain.com/spa1` and `your-custom-domain.com/spa2`), you would typically use a more advanced setup involving a reverse proxy or custom CDN rules to route traffic to different storage containers based on the URL path.
- **Caching**: Ensure CDN caching settings are configured appropriately to avoid stale content issues.
- **HTTPS**: Ensure that HTTPS is enabled on your CDN endpoints and custom domains for secure access.

By following this approach, you can efficiently manage multiple SPAs using the same custom domain with Azure Blob Storage and Azure CDN.

## Private internal Custom DNS

Yes, you can map an internal custom domain to Azure Blob Storage using Azure services like Azure Private Link and Azure CDN, but the approach differs slightly from public domain setups. Here’s a detailed guide on how to configure an internal custom domain with Azure Blob Storage:

### Key Components

1. **Azure Blob Storage**: Stores your static content.
2. **Azure Private Link**: Provides private access to Azure Storage from your virtual network.
3. **Azure CDN (optional)**: Can be used for additional caching and performance optimization, although it typically works with public domains.
4. **DNS Configuration**: Uses an internal DNS zone for mapping the custom domain within your private network.

### Step-by-Step Guide

#### 1. **Set Up Azure Blob Storage**

1. **Create a Storage Account**:
   Create an Azure Storage Account as usual, and configure it for static website hosting if required.

   ```hcl
   resource "azurerm_storage_account" "example" {
     name                     = "examplestoracc"
     resource_group_name      = azurerm_resource_group.example.name
     location                 = azurerm_resource_group.example.location
     account_tier             = "Standard"
     account_replication_type = "LRS"
     enable_https_traffic_only = true
   }

   resource "azurerm_storage_container" "static_website" {
     name                  = "$web"
     storage_account_name  = azurerm_storage_account.example.name
     container_access_type = "container"
   }
   ```

2. **Upload Your SPA Content**:
   Upload the build files of your SPAs to the appropriate containers within the storage account.

#### 2. **Set Up Azure Private Link**

1. **Create a Private Endpoint for Azure Storage**:
   This allows private connectivity from your virtual network to your storage account.

   ```hcl
   resource "azurerm_private_endpoint" "storage" {
     name                = "example-private-endpoint"
     resource_group_name = azurerm_resource_group.example.name
     location            = azurerm_resource_group.example.location
     subnet_id           = azurerm_subnet.example.id

     private_service_connection {
       name                           = "example-private-link"
       private_connection_resource_id = azurerm_storage_account.example.id
       is_manual_connection           = false
       subresource_names              = ["blob"]
     }
   }
   ```

2. **Create a Private Link Service Connection**:
    - This is typically managed through the Azure Portal or CLI, where you link the private endpoint to the storage account.

#### 3. **Configure DNS for Internal Custom Domain**

1. **Set Up an Internal DNS Zone**:
    - Create a DNS zone within Azure DNS or another internal DNS service that your network uses.

   ```hcl
   resource "azurerm_private_dns_zone" "example" {
     name                = "internal.your-custom-domain.com"
     resource_group_name = azurerm_resource_group.example.name
   }
   ```

2. **Create DNS Records for Storage Account**:
    - Create DNS records to map your internal custom domain to the storage account.

   ```hcl
   resource "azurerm_private_dns_a_record" "storage" {
     name                = "example"
     zone_name           = azurerm_private_dns_zone.example.name
     resource_group_name = azurerm_resource_group.example.name
     ttl                 = 3600
     records             = [azurerm_storage_account.example.primary_blob_endpoint]
   }
   ```

    - Alternatively, if you are using a custom domain, you can set up a CNAME record if necessary.

#### 4. **Accessing the Storage Account**

- **Private Network Access**: Ensure that your network is configured to resolve the internal DNS records correctly and that your network can access the private endpoint.
- **Testing**: Access the SPA using the internal custom domain from within your network to verify that it is correctly mapped.

### Additional Considerations

- **Security**: Make sure to configure network security groups (NSGs) and virtual network service endpoints properly to ensure that only authorized traffic can reach your private endpoint.
- **Performance**: If you use Azure CDN, configure it with private endpoints and internal domains, but note that internal CDN setups can be complex and may require additional configuration.

By following these steps, you can map an internal custom domain to an Azure Blob Storage endpoint, allowing you to serve your SPAs securely and privately within your network.